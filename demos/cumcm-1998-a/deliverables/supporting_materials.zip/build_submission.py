"""Build the historical-demo paper, honest AI disclosure and support archive."""
import argparse
import csv
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import textwrap
import zipfile
import re
from xml.sax.saxutils import escape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, Image, Preformatted, Flowable, KeepTogether, XPreformatted

p=argparse.ArgumentParser();p.add_argument('--case',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
a=p.parse_args();case=a.case.resolve();dest=a.output.resolve();dest.mkdir(parents=True,exist_ok=True)
receipts=sorted((case/'runs').glob('*/receipt.json'))
receipt=json.loads(receipts[-1].read_text());run=receipts[-1].parent
assert receipt['status']=='automatic-checks-passed'
r=json.loads((run/'output/results.json').read_text());checks=json.loads((run/'checks.json').read_text())
support=dest.parent/'support-source';support.mkdir(exist_ok=False)
for sub in ['code','data','reference','figures']:(support/sub).mkdir()
for name in ['model.py','validate.py']:shutil.copyfile(case/'code'/name,support/'code'/name)
for name in ['assets4.csv','assets15.csv']:shutil.copyfile(case/'raw/data'/name,support/'data'/name)
for name in ['results.json','four-frontier.csv','fifteen-frontier.csv']:shutil.copyfile(run/'output'/name,support/'reference'/name)
for name in ['four-frontier.png','fifteen-frontier.png']:shutil.copyfile(run/'output'/name,support/'figures'/name)
shutil.copyfile(run/'checks.json',support/'reference/checks.json')
shutil.copyfile(Path(__file__).with_name('run_demo.py'),support/'run_demo.py')
shutil.copyfile(__file__,support/'build_submission.py')
shutil.copyfile(Path(__file__).with_name('equations.json'),support/'equations.json')
shutil.copyfile(Path(__file__).with_name('check_recommendation.py'),support/'check_recommendation.py')
shutil.copyfile(Path(__file__).with_name('recommendation.json'),support/'reference/recommendation.json')
rec=json.loads(Path(__file__).with_name('recommendation.json').read_text())['groups']
shutil.copyfile(Path(__file__).with_name('make_equations.py'),support/'make_equations.py')
shutil.copyfile(Path(__file__).with_name('runtime-versions.json'),support/'runtime-versions.json')
versions=json.loads(Path(__file__).with_name('runtime-versions.json').read_text())
(support/'requirements.txt').write_text('\n'.join(f'{k}=={v}' for k,v in versions.items())+'\n')
(support/'report-requirements.txt').write_text('reportlab=='+importlib.metadata.version('reportlab')+'\n')
source_url='https://www.mcm.edu.cn/upload_cn/node/1/SkAh1A7Q6f2dd01e58aa621f920e79f45cd5d255.pdf'
format_url='https://www.mcm.edu.cn/html_cn/node/4cd596519c9eb9fbd866398f6df0caa3.html'
ai_url='https://www.mcm.edu.cn/html_cn/node/fef94648f2836ab6cc81586f4c38512b.html'
(support/'sources.json').write_text(json.dumps({'historical_problem':'CUMCM 1998 A','official_url':source_url,
 'pdf_page':11,'official_pdf_sha256':hashlib.sha256((case/'raw/problem/official-1992-2000.pdf').read_bytes()).hexdigest(),
 'tables':'Two tables manually transcribed and visually reviewed by the AI assistant; not human verification.',
 'format_reference':format_url,'ai_policy_reference':ai_url,'review_date':'2026-10-07'},ensure_ascii=False,indent=2))
(support/'README.md').write_text('# 《投资的收益和风险》支撑材料\n\n## 结果复现\n\n采用 Python 3.12，安装 requirements.txt 中列出的依赖，在本目录执行：\n\n    uv venv .venv --python 3.12\n    uv pip install --python .venv/bin/python -r requirements.txt\n    .venv/bin/python run_demo.py\n\nWindows 将 .venv/bin/python 替换为 .venv/Scripts/python.exe。\n\nrun_demo.py 读取 data/ 的两组资产参数，运行 code/model.py 求解和 code/validate.py 独立核验，再与 reference/results.json 比较。生成结果写入 reproduced/；若该目录已存在则拒绝覆盖。模型计算采用资金 100 万元，风险上限与论文一致；资金与风险定义及适用条件见论文。\n\n## 文件用途\n\n- code/model.py：建模、优化求解、风险—收益曲线和结果生成。\n- code/validate.py：约束、现金流、解析上界及四资产费用分区穷举核验。\n- run_demo.py：完整计算与验证入口；运行不依赖 Praxis 或 AI 服务。\n- data/：题目两组资产参数；出处与录入核对情况见 sources.json。\n- check_recommendation.py：定位收益—风险曲线的拐点，并以解析上界核验；结果写入 reproduced/recommendation.json。\n- reference/：论文对应结果、曲线数值及核验记录。\n- figures/：论文使用的风险—收益图。\n- requirements.txt、runtime-versions.json：计算依赖和版本。\n- build_submission.py、make_equations.py、equations.json、report-requirements.txt：论文编排与公式生成工具。编排脚本需原案例运行记录和原题副本，字体路径使用 macOS；不是数学结果复现入口。\n- AI工具使用详情.pdf：AI 工具名称、用途、过程及采纳与核验情况。\n\n完整建模、核验和复现源程序同时列于论文附录 B。支撑材料文件清单列于论文附录 A。\n')
font='/System/Library/Fonts/Supplemental/Songti.ttc'
if Path(font).exists():pdfmetrics.registerFont(TTFont('Chinese',font,subfontIndex=6))
else:pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'));pdfmetrics.registerFontFamily('Chinese',normal='STSong-Light')
if Path(font).exists():
    pdfmetrics.registerFont(TTFont('ChineseBold',font,subfontIndex=1))
    assert pdfmetrics.getFont('Chinese').face.name == b'STSongti-SC-Regular'
pdfmetrics.registerFont(TTFont('Latin','/System/Library/Fonts/Supplemental/Times New Roman.ttf'))
pdfmetrics.registerFont(TTFont('Code','/System/Library/Fonts/Supplemental/Courier New.ttf'))
pdfmetrics.registerFont(TTFont('LatinItalic','/System/Library/Fonts/Supplemental/Times New Roman Italic.ttf'))
F='Chinese' if Path(font).exists() else 'STSong-Light'
style=ParagraphStyle('body',fontName=F,fontSize=12,leading=19,spaceAfter=7,firstLineIndent=24,wordWrap='CJK')
heading=ParagraphStyle('heading',parent=style,fontName='ChineseBold' if Path(font).exists() else F,fontSize=14,leading=21,spaceBefore=12,spaceAfter=10,firstLineIndent=0,keepWithNext=True)
title=ParagraphStyle('title',parent=style,fontName='ChineseBold' if Path(font).exists() else F,fontSize=18,leading=27,firstLineIndent=0,alignment=TA_CENTER,spaceAfter=20)
small=ParagraphStyle('small',parent=style,fontSize=10.5,leading=15,firstLineIndent=0)
flow=[]
def rich(text):
    # Separate Latin and CJK faces; symbols use italic letters with real subscripts.
    pieces=re.split(r'(\b(?:[xrfqpuhvt][0i]|rho)\b)',text)
    out=[]
    for piece in pieces:
        if re.fullmatch(r'[xrfqpuhvt][0i]',piece):
            out.append('<font name="LatinItalic">'+piece[0]+'</font><sub><font name="Latin">'+piece[1]+'</font></sub>')
        elif piece=='rho':out.append('<font name="LatinItalic">ρ</font>')
        else:
            for chunk in re.split(r'([\x20-\x7e]+)',piece):
                value=escape(chunk)
                out.append('<font name="Latin">'+value+'</font>' if chunk and chunk.isascii() else value)
    return ''.join(out)
def para(text,kind=style):
    markup=rich(text)
    if kind is style:markup=re.sub(r'\[(\d+)\]',r'<super>[\1]</super>',markup)
    flow.append(Paragraph(markup,kind))
class MathFormula(Flowable):
    def __init__(self,data,number):
        Flowable.__init__(self);self.data=data;self.number=number
        self.scale=1.25;self.width=445;self.height=data['height']*self.scale+16
    def draw(self):
        c=self.canv;d=self.data;c.saveState();c.translate((420-d['width']*self.scale)/2,8+d['depth']*self.scale);c.scale(self.scale,self.scale)
        for glyph in d['paths']:
            p=c.beginPath();verts=glyph['verts'];codes=glyph['codes'];j=0;last=(0,0)
            while j<len(codes):
                op=codes[j];x,y=verts[j]
                if op==1:p.moveTo(x,y);last=(x,y);j+=1
                elif op==2:p.lineTo(x,y);last=(x,y);j+=1
                elif op==3:
                    ex,ey=verts[j+1];p.curveTo(last[0]+2*(x-last[0])/3,last[1]+2*(y-last[1])/3,ex+2*(x-ex)/3,ey+2*(y-ey)/3,ex,ey);last=(ex,ey);j+=2
                elif op==4:
                    x2,y2=verts[j+1];ex,ey=verts[j+2];p.curveTo(x,y,x2,y2,ex,ey);last=(ex,ey);j+=3
                elif op==79:p.close();j+=1
                else:raise ValueError(op)
            c.drawPath(p,fill=1,stroke=0)
        c.restoreState();c.setFont('Latin',11);c.drawRightString(445,self.height/2-3,'('+str(self.number)+')')
equations=json.loads((support/'equations.json').read_text());equation_count=0
def equation(index):
    global equation_count
    equation_count+=1;flow.append(MathFormula(equations[index],equation_count))
table_count=0

def section(text):para(text,heading)
def newpage():flow.append(PageBreak())
def table(rows,widths=None):
    global table_count
    table_count+=1
    names=['四资产题设参数','符号与单位','四资产代表方案收益','四资产购买本金及交易费用（元）','十五资产代表方案收益','十五资产代表配置','四资产资金规模情景','十五资产资金规模情景','十五资产题设参数']
    caption=Paragraph('表 '+str(table_count)+'  '+names[table_count-1],ParagraphStyle('caption',parent=small,alignment=TA_CENTER,keepWithNext=True,spaceAfter=6))
    t=Table([[Paragraph(rich(str(v)),small) for v in row] for row in rows],colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('LINEABOVE',(0,0),(-1,0),.9,colors.black),('LINEBELOW',(0,0),(-1,0),.5,colors.black),('LINEBELOW',(0,-1),(-1,-1),.9,colors.black),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]));
    if table_count==9:t.setStyle(TableStyle([('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),2)]))
    flow.extend([KeepTogether([caption,t]),Spacer(1,10)])
def footer(c,doc):
    c.setAuthor('');c.setTitle(doc.title)
    c.setFont(F,8);c.drawCentredString(A4[0]/2,34,str(doc.page))
def build(path,items):
    SimpleDocTemplate(str(path),pagesize=A4,leftMargin=72,rightMargin=80,topMargin=72,bottomMargin=72,title=path.stem,author='').build(items,onFirstPage=footer,onLaterPages=footer)
def pct(v):return f'{v*100:.3f}%'
def money(v):return f'{0 if abs(v)<.005 else v:,.2f}'

para('投资的收益和风险：含最低交易费的组合优化',title)
para('摘 要',heading)
f=r['groups']['four']['selected'][1];g=r['groups']['fifteen']['selected'][1]
para('针对含最低交易费的资产配置问题，建立银行存款与风险资产之间的收益—风险组合优化模型。将资金总额和可承受风险作为决策参数，在给定风险上限下最大化净收益，构造供公司选择的投资方案。')
para('将购买金额、交易费和银行存款共同纳入预算；不购买时费用为零，正购买时费用为费率乘购买金额与门槛金额的较大值。利用二元启用变量建立混合整数线性规划，并以最大单项风险损失额占初始资金比例作为风险指标。')
para(f'当可用资金为 100 万元时，四资产风险上限 1% 时，购买 S1 {money(f["investments_yuan"][0])} 元、S2 {money(f["investments_yuan"][1])} 元，净收益 {money(f["profit_yuan"])} 元，净收益率 {pct(f["net_return"])}；十五资产风险上限 10% 时，净收益率为 {pct(g["net_return"])}。两组各计算 61 个风险上限；代表方案均与独立解析上界吻合。没有风险偏好时，取收益—风险曲线的拐点作推荐：四资产风险上限 {rec["four"]["knee_risk"]*100:.1f}%、净收益率 {pct(rec["four"]["knee_net_return"])}，十五资产 {rec["fifteen"]["knee_risk"]*100:.0f}%、{pct(rec["fifteen"]["knee_net_return"])}，均达到解析上界。')
para('四资产进一步通过 81 种费用分段的枚举与连续背包计算独立核验。资金和风险参数情景揭示：最低交易费在小资金下会改变组合；将风险理解为所选资产最大风险率时，方案会明显改变。因此结果仅适用于所采用定义与题目参数，模型同时给出最低交易费生效条件，为不同资金规模下的组合选择提供依据。')
para('关键词：投资组合；混合整数规划；最低交易费；风险约束；独立验证')
newpage()
section('1 问题重述与数据核对')
para('问题重述。公司有一笔数额为 M 的资金，可购买 n 种资产 Si，也可存银行（利率 r0=5%，无费用无风险）。购买 Si 的平均收益率为 ri、风险损失率为 qi，交易费率为 pi，购买额不超过 ui 时按 ui 计费；总体风险按所投资资产中最大的一个风险度量。原题要求：（1）对表 1 的四种资产设计投资组合，使净收益尽可能大、总体风险尽可能小；（2）讨论一般情形，并对表 9 的十五种资产计算。原始数据来自全国组委会官方历史赛题汇编第 11 页 [1]，收益率、风险损失率和费率在计算时由百分数转为小数，门槛金额以元计。本文的处理是：先固定风险上限求净收益最大的方案，扫描风险上限得到方案族，再给出无偏好时的拐点推荐。')
para('资金总额 M 与公司风险偏好未提供。本文取 M=1,000,000 元作为数值分析基准，并考察 M=100、1,000、10,000 元。资金总额保留为模型参数，各风险上限对应一个收益最优方案；公司可根据可承受风险选择配置。')
para('文献定位。含固定交易费与最小交易量的组合选择，在文献中通常写成混合整数线性规划，规模大时再用启发式求解 [4]；本题收益与损失率为给定参数、没有历史序列，不能估计 Markowitz 均值—方差模型所需的协方差 [5]。本文采用的最大单项损失额度量，与以最坏损失而非方差衡量风险、并可用线性规划处理的极小极大思路同属一类 [6]，但对象不同：它约束各资产风险损失额的最大值，而非历史收益序列的最小值。')
table([['资产','收益率 %','风险率 %','费率 %','门槛 元']]+[[d[k] for k in ['asset','return_pct','risk_pct','fee_pct','threshold_yuan']] for d in r['groups']['four']['assets']],[55,85,85,80,140])
section('2 假设、定义与符号')
para('采用单时期、无卖空、资金可连续分割；题目收益率与风险率视为本期给定参数。银行利率 r0=5%，无风险和交易费。没有观测时间序列，不估计相关性、收益分布或市场预测精度，也不将风险率解释成违约概率。税收、流动性与跨期再平衡不在题目数据内。')
table([['符号','含义与单位'],['M','初始可用资金，元'],['x0 / xi','银行存款 / 第 i 项购买本金，元'],['ri / qi / pi','收益率、题设风险损失率、交易费率，无量纲'],['ui / fi','费用计费门槛 / 实际交易费，元'],['yi','启用变量，0 或 1'],['rho / R','风险上限 / 最大单项风险暴露额占 M 的比例']],[85,360])
para('风险采用最大单项金额暴露占初始资金的比例，而非所选资产风险率的最大值。这是本文为体现分散投资效果所采用的操作定义，不是由题目数据识别出的损失分布。原文的另一种解释在第 7 节比较。ui 是最低计费基数，不是最低购买额；交易费函数为：')
equation(0)
para('单时期、连续分割和忽略税收使预算模型可线性化；若交易要求整手购买，则需增加整数购买单位，本文结果不再直接适用。若费用另有资金支付或原题收益率已扣费，也须改变下面的现金流模型。')
section('3 一般模型与精确求解')
section('3.1 现金流与风险约束')
para('交易费在购买时从初始资金支付。期末财富由银行本息及风险资产本息组成；期末财富减去初始投入，得到净利润。因此费用只计入利润一次，不能因为预算也含费用就再重复扣减。')
equation(1);equation(2);equation(3);equation(4)
para('收益率为净利润除以初始资金。风险指标仅约束资金暴露；没有收益与损失的联合分布，故不把风险参数额外扣入期望收益。给定不同风险上限得到一族条件最优方案，全银行提供净收益率 5% 的可行基线。')
section('3.2 混合整数线性表示')
para('将金额除以初始资金归一化，避免资金尺度使约束系数悬殊。对每种资产加入二元启用变量；其具体定义和优化问题如下（所有逐项约束均对 i=1,…,n 成立）：')
equation(5);equation(6);equation(7);equation(8);equation(9)
para('当 yi=0 时购买额与费用均为零；当 yi=1 时费用至少等于两种计费值的较大者。由于过高费用既直接减少利润又占用可生息预算，最优解不会多付费用，故在最优解处该表示与分段收费等价。即使启用变量为 1 而购买额为零，取消启用并把费用转存银行也会严格增加收益，故这种状态不会成为最优解。费用上界利用归一化购买额不超过 1 推导，避免任意超大的常数。')
para('用 SciPy 的 milp 接口 [2] 和 HiGHS 求解 [3]，相对最优间隙设为 1e-9，单次上限 20 秒；本次均求得最优状态。每组扫描 61 个风险上限，四资产范围 0 到 3%，十五资产范围 0 到 60%。离散扫描展示收益包络，不声称给出全部连续前沿或所有并列最优解。')
section('4 四资产结果')
table([['风险上限','实际风险','净收益率','净收益 元','银行 元']]+[[pct(d['risk_cap']),pct(d['actual_risk']),pct(d['net_return']),money(d['profit_yuan']),money(d['bank_yuan'])] for d in r['groups']['four']['selected']],[75,75,80,115,100])
table([['风险上限','S1 本金','S2 本金','S3 本金','S4 本金','费用合计']]+[[pct(d['risk_cap'])]+[money(x) for x in d['investments_yuan']]+[money(sum(d['fees_yuan']))] for d in r['groups']['four']['selected']],[60,77,77,77,77,77])
para('风险上限 0.5% 时四种资产都有配置，并保留存款；到 1% 时方案集中在 S1 与 S2。该结果说明“分散越多越好”不是收益最优的通用规则；具体组合取决于风险限制和净收益机会成本。不同风险上限不能直接作优劣排名。')
flow.append(Image(str(support/'figures/four-frontier.png'),width=440,height=246));para('图 1 四资产风险上限与最优净收益率；点为代表方案，横轴为约束上限。',small)
section('5 十五资产结果与一般扩展')
table([['风险上限','实际风险','净收益率','净收益 元']]+[[pct(d['risk_cap']),pct(d['actual_risk']),pct(d['net_return']),money(d['profit_yuan'])] for d in r['groups']['fifteen']['selected']],[95,95,95,160])
para('十五资产采用与四资产完全相同的模型，全部参数见支撑材料 data/assets15.csv。一般 n 情形有 3n+1 个变量，其中 n 个二元变量；新增资产不要求更换方法。规模更大时求解耗时与启用组合有关，应保留实际最优间隙，不能只凭求解器返回可行解宣称全局最优。')
d=g;active=[(asset['asset'],x,fee) for asset,x,fee in zip(r['groups']['fifteen']['assets'],d['investments_yuan'],d['fees_yuan']) if x>1e-6]
table([['风险上限 10% 的启用资产','购买本金 元','交易费 元']]+[[name,money(x),money(fee)] for name,x,fee in active],[175,140,130])
para(f'该方案交易费合计 {money(sum(g["fees_yuan"]))} 元。无风险限制时，四资产最优净收益率 {pct(r["groups"]["four"]["unrestricted"]["net_return"])}，十五资产为 {pct(r["groups"]["fifteen"]["unrestricted"]["net_return"])}；相应集中投资的风险更高。没有公司偏好输入，本文不把某个风险上限当作唯一最优；第 8 节按明确规则给出一个拐点推荐。')
flow.append(Image(str(support/'figures/fifteen-frontier.png'),width=440,height=246));para('图 2 十五资产最优收益包络；平台区不表示风险上限全部被用尽。',small)
section('6 独立核验与最优性证据')
para('首先从原始 CSV 独立重算预算、分段费用、利润与实际风险，检查非负性和约束；随后检查零风险退化为全银行、收益包络单调以及无风险限制下的解析答案。')
para('四资产的核验不调用优化求解器：逐项取“不买／低于门槛／高于门槛”三种状态，共 3^4=81 种。在每个状态中，费用已是仿射函数，资金约束成为带上下限的连续背包；先分配下限，再按边际利润与边际预算比从高到低分配，获得该状态的确切最优值。取所有状态的最大值，与 MILP 比较。')
section('6.1 比例费用松弛与解析上界')
para('命题 1（上界）。去掉最低计费门槛、仅保留比例费用 pi·xi 的松弛问题，其最优值 U 不小于原问题的最优值。证明：设 x 为原问题的任一可行方案，其交易费 fi=pi·max(xi, ui) ≥ pi·xi。把 x 放入松弛问题，各项费用降为 pi·xi，节省的费用可存入银行；预算仍满足，风险暴露不变，净收益不减。因此 x 在松弛问题中可行且收益不低，U 是原问题的上界，不是另一个经验近似答案。∎ 将银行余额由预算消去，松弛问题为：')
equation(10);equation(11);equation(12)
para('其中 wi 是每单位购买本金消耗的预算，gi 是扣除银行机会成本后的增量净收益。命题 2（松弛问题的解）。只有 gi>0 的资产值得购买；按单位预算增益 ηi=gi/wi 从高到低依次分配，每种资产取剩余预算 B 与单项风险上限所允许的较小值：')
equation(13)
para('证明（交换论证）：设某最优分配中，增益比较低的资产获得了正的预算，而增益比较高的资产尚未到达风险上限。把一小部分预算从前者转给后者，预算消耗不变，目标函数增加（两者增益比之差乘转移量），与最优性矛盾。故最优分配必按 ηi 排序，依次填满上限或耗尽预算，即得精确解 U。若净增益都非正，保留银行存款即可。∎')
para('命题 3（最优性证书）。由命题 1，原问题任一可行方案的收益率不超过 U，因此可行方案的收益率等于 U 时它是全局最优：')
equation(14)
para('本次两组各三个代表方案以及第 8 节的两个拐点方案均达到上界。小资金方案可能落在最低费用段，不能自动使用上界相等的证书。')
section('6.2 一般资金规模下的解析条件')
para('命题 4（充分资金阈值）。记比例费用松弛的最优配置为归一化购买额 v*，给定风险上限，定义：')
equation(15)
para('当 M ≥ Mcrit 时，每个启用资产的购买本金 M·vi* 不低于门槛 ui，其费用 pi·max(xi, ui) 等于 pi·xi，故松弛最优配置对原问题可行且收益等于 U；由命题 1 它是原问题最优解，净收益率与 M 无关。∎ 若没有资产启用，阈值记为零。低于阈值只说明该证书失效，仍应用分段费用模型求解，不能断言收益必定下降。')
critical={}
for key in ['four','fifteen']:
    group=r['groups'][key];d=group['selected'][1]
    critical[key]=max(float(asset['threshold_yuan'])/(x/d['budget_yuan']) for asset,x in zip(group['assets'],d['investments_yuan']) if x>1e-7)
para(f'四资产风险上限 1% 时，资金阈值约为 {critical["four"]:.2f} 元；十五资产风险上限 10% 时约为 {critical["fifteen"]:.2f} 元。为避免金额四舍五入低于边界，可分别取 339 元与 2,602 元作为充分资金条件。该结论解释了第 7 节中资金超过门槛后最优收益率保持不变的现象。')
section('6.3 数值证据与检验边界')
passed=sum(c['passed'] for c in checks);para(f'本次 {passed}/{len(checks)} 项检查通过。支撑材料 reference/checks.json 记录实际误差、约束残差及证书间隙；这 12 项包含可行性、会计恒等式和性质检验，并非 12 种独立求解算法；真正独立的最优性核验为费用分段枚举与比例费用解析上界。数值误差以 1e-7 的无量纲容差处理，金额表按分四舍五入，极小负银行残差在展示时记为零。')
section('7 资金规模、参数与解释敏感性')
for key,label in [('four','四资产，风险上限 1%'),('fifteen','十五资产，风险上限 10%')]:
    para(label)
    table([['资金 元','净收益率','交易费 元']]+[[money(d['budget_yuan']),pct(d['net_return']),money(sum(d['fees_yuan']))] for d in r['sensitivity'][key]['budget']],[145,145,155])
para('资金情景是自行设定的压力检查，100 元情景偏离原题“相当大资金”的描述，专用于检验门槛。资金大到所有启用投资超过门槛后，比例归一化使最优收益率不再随 M 改变；资金小时固定最低计费会影响收益和选择。')
for key,label in [('four','四资产'),('fifteen','十五资产')]:
    ds=r['sensitivity'][key]['risk_stress'];para(label+'：将全部 qi 乘以 0.9、1、1.1，在同一风险上限下重新求解，收益率依次为 '+ '、'.join(pct(d['net_return']) for d in ds)+'。')
para('这三个乘数没有经验分布依据，只是参数情景，不是置信区间或真实发生概率。风险率增大使可行域缩小，最优收益不应增大，本次检查符合该性质。')
para('若将总体风险定义为已选资产的最大 qi，则四资产 1% 上限下无风险资产合格；十五资产 10% 上限下虽有低风险资产，但其费用后的收益不优于银行，因此两者均选择全银行并获得 5%。解释改变会从根本上改变结果，因此风险指标的操作定义应与公司的决策目标一致。')
section('8 模型评价与条件建议')
para('优点是费用与预算一致、两组问题共用一般模型、有可复现输出与独立最优性证据。限制是最大单项损失只是一种题设风险代理，不是组合方差、尾部总损失或概率保证；缺少相关性与收益分布，不能代表真实市场投资。返回的是条件最优方案之一，而非所有可能的并列方案。')
fo,ff=rec['four'],rec['fifteen']
def plan(d,names):return '、'.join(f'{names[i]} {money(x)} 元' for i,x in enumerate(d['investments_yuan']) if x>1e-6)
para(f'推荐方案。没有风险偏好输入时，取收益—风险曲线的拐点作为有规则的推荐，而不是唯一最优：把净收益率从零风险值到饱和值、风险上限从零到饱和上限分别重标为 [0,1]，取曲线高出两端连线最多的一点。四资产拐点在风险上限 {fo["knee_risk"]*100:.1f}%：购买 {plan(fo,["S1","S2","S3","S4"])}，银行存款为零，净收益率 {pct(fo["knee_net_return"])}；已取得可得增益的 {fo["share_of_gain"]*100:.1f}%，风险上限只用了饱和上限（{fo["saturation_risk"]*100:.1f}%）的 {fo["share_of_saturation_risk"]*100:.0f}%。拐点前后局部斜率约为 {fo["slope_before"]:.1f} 与 {fo["slope_after"]:.1f}，即风险上限每提高 0.1 个百分点，净收益率约增加 {fo["slope_before"]/10:.2f} 与 {fo["slope_after"]/10:.2f} 个百分点。')
para(f'十五资产的拐点在 {ff["knee_risk"]*100:.0f}%（扫描步长 {ff["grid_step"]*100:.0f} 个百分点）：{plan(ff,["S%d"%i for i in range(1,16)])}；净收益率 {pct(ff["knee_net_return"])}，取得增益的 {ff["share_of_gain"]*100:.1f}%，风险上限仅为饱和上限（{ff["saturation_risk"]*100:.0f}%）的 {ff["share_of_saturation_risk"]*100:.0f}%。该曲线较平缓，拐点前后斜率只有 {ff["slope_before"]:.2f} 与 {ff["slope_after"]:.2f}，推荐的依据弱于四资产。两个拐点处的可行方案都等于解析上界（{pct(fo["analytic_upper_bound"])}、{pct(ff["analytic_upper_bound"])}），因而是各自风险上限下的全局最优；这两项核验另见 reference/recommendation.json。拐点规则只是对风险偏好居中的约定，公司偏好明确时应直接按其风险上限选择。')
para('建议公司先确认可用资金、可承受的损失额与风险定义，再选对应风险上限的组合；若真实目标改成总损失、流动性或多时期决策，需要重新建模。提高模型复杂度不能弥补缺失数据。')
section('AI工具使用声明')
para('本论文使用了 AI 工具，主要用于模型推导、代码编写、计算验证、结果分析及论文编排，详细使用情况见支撑材料 AI工具使用详情.pdf。')
section('参考文献')
refs=[
 '[1] 全国大学生数学建模竞赛组委会. 1992—2000 年全国大学生数学建模竞赛赛题汇编：1998 年 A 题，PDF 第 11 页[EB/OL]. [2026-10-07]. '+source_url,
 '[2] SCIPY DEVELOPERS. scipy.optimize.milp: SciPy API reference[EB/OL]. [2026-10-07]. https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.milp.html',
 '[3] HiGHS DEVELOPMENT TEAM. HiGHS: high performance software for linear optimization[EB/OL]. [2026-10-07]. https://highs.dev/',
 '[4] KELLERER H, MANSINI R, SPERANZA M G. Selecting portfolios with fixed costs and minimum transaction lots[J]. Annals of Operations Research, 2000, 99: 287-304.',
 '[5] MARKOWITZ H. Portfolio selection[J]. The Journal of Finance, 1952, 7(1): 77-91.',
 '[6] YOUNG M R. A minimax portfolio selection rule with linear programming solution[J]. Management Science, 1998, 44(5): 673-683.']
for text in refs:para(text,small)
newpage()
section('附录 A 数据与支撑材料文件列表')
para('十五资产参数来自原题第二张表 [1]，供不运行程序的读者复核；收益、风险与费用列单位均为百分数，门槛为元。')
table([['资产','收益率 %','风险率 %','费率 %','门槛 元']]+[[d[k] for k in ['asset','return_pct','risk_pct','fee_pct','threshold_yuan']] for d in r['groups']['fifteen']['assets']],[55,85,85,80,140])
para('supporting_materials.zip 含以下文件；reproduced/ 为重跑时新生成，不纳入原提交包。各文件对应本文的数据、数值结果与计算过程。')
paths=[path.relative_to(support).as_posix() for path in sorted(support.rglob('*')) if path.is_file()]+['AI工具使用详情.pdf']
rows=[paths[i:i+2]+([''] if len(paths[i:i+2])==1 else []) for i in range(0,len(paths),2)]
files=Table([[Paragraph(rich(v),small) for v in row] for row in rows],colWidths=[222,223],hAlign='LEFT')
files.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),1),('BOTTOMPADDING',(0,0),(-1,-1),1)]))
flow.append(files)
newpage()
section('附录 B 完整源程序')
para('以下列出建模、独立核验及结果复现的完整源码。程序按支撑包运行说明执行；公式生成与论文编排脚本另附于支撑包。')
code_style=ParagraphStyle('code',fontName=F,fontSize=8,leading=11)
def code_width(text):return sum(pdfmetrics.stringWidth(c,'Code' if ord(c)<128 else F,8) for c in text)
def code_lines(lines):
    return '\n'.join(''.join('<font name="Code">'+escape(c)+'</font>' if c.isascii() else escape(c) for c in re.split(r'([\x20-\x7e]+)',line)) for line in lines)
for index,path in enumerate([support/'code/model.py',support/'code/validate.py',support/'run_demo.py']):
    if index:newpage()
    lines=[]
    for line in path.read_text().splitlines():
        segment=''
        for char in line:
            if code_width(segment+char)>440:
                lines.append(segment);segment=''
            segment+=char
        lines.append(segment)
    flow.append(KeepTogether([Paragraph(rich(path.relative_to(support).as_posix()),heading),XPreformatted(code_lines(lines[:5]),code_style)]))
    flow.append(XPreformatted(code_lines(lines[5:]),code_style))
build(dest/'paper.pdf',flow)
# A separate disclosure has its own readable compact layout.
style=ParagraphStyle('ai-body',parent=style,fontSize=10.5,leading=16,firstLineIndent=21)
heading=ParagraphStyle('ai-heading',parent=heading,fontSize=12,leading=18,spaceBefore=8,spaceAfter=8)
title=ParagraphStyle('ai-title',parent=title,fontSize=16,leading=24)
# para's default style is bound at definition time; pass the current style explicitly.
old_para=para
def para(text,kind=None):old_para(text,style if kind is None else kind)
flow=[]
para('AI工具使用详情',title)
para('历史题目演练；本说明如实记录当前可见过程，不是完整聊天导出。',small)
section('1 工具名称与型号')
para('使用工具为 OpenAI Codex；后续增加文献定位与拐点推荐、重建论文与支撑包时，使用 Anthropic Claude（Sonnet 5.5）与 Claude Code。当前会话系统标识为基于 GPT-6 的助手，精确后台模型版本与构建号无法从本演练独立核实，未作假定。实际数学计算使用 Python 3.12、NumPy、SciPy/HiGHS 和 Matplotlib；论文编排使用 ReportLab，公式用 Matplotlib MathText 的 STIX 字形转为矢量轮廓；这是数学公式排版，不是完整 LaTeX 引擎。计算库版本保存在 requirements.txt。')
section('2 目的、提示方式与使用过程')
para('任务是挑选一道经典历史题，从题目分析、建模、验证到可提交文件完整演练一遍。本说明记录实际执行过程，不收录对话原文，也没有捏造其他提示或完整回复。')
para('助手自主选择 1998 A，读取官方原页并录入两张数据表；识别 M、风险偏好及风险定义缺口；提出含最低计费的 MILP；编写模型和不同数学构造的验证器；真实执行、比较资金与风险情景、形成图表与报告。本轮另查阅组委会公开论文展示 C023 的摘要与问题重述页，用于检查写作组织，未移植其模型、数据或结论；未获得可核实的 1998 A 官方标准答案。论文新增的三篇参考文献只核对了题录，未阅读全文，仅用于说明模型定位。')
section('3 采纳、修改与核验')
para('本稿采纳了助手提出的风险损失额定义、费用预算模型、MILP 表示、数值方案和报告表述。助手核验包括原页目视核对、预算和费用重算、四资产费用分段枚举、代表点解析上界、边界与参数单调性，并保留实际 checks.json。助手增加 100 元资金情景以检验最低费用边界。随后的审查覆盖字体、引文、方法与论文质量；助手修正宋体字面、公式、表格编号、参考文献和最优性推导，并把先前误称的 13 项检查纠正为真实的 12 项。此外，报告改为按考题直接作答：助手删除正文过程性旁注、重写摘要，并补充一般资金规模的充分阈值推导；实际人工核验状态仍在本说明如实记录。')
para('以上是 AI 助手核验和程序检查，不能称作用户或队伍人工审核。本次没有记录用户对核心假设、代码、结论和版面的逐项人工审核，也没有假称用户已作修改。正式比赛的真实队伍需主导核心分析并人工复核；本包仅为训练示范，不作正式合规认证。')
section('4 记录范围与出处')
para('本说明只含任务概述和当前实际执行摘要，不声称完整保存对话。没有导出系统提示、私密资料或隐含推理。格式依据为 2026 年试行规定，自 2026-09-01 起生效。出处：'+ai_url)
build(support/'AI工具使用详情.pdf',flow)
with zipfile.ZipFile(dest/'supporting_materials.zip','w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(support.rglob('*')):
        if path.is_file():z.write(path,path.relative_to(support))
manifest={}
for path in [dest/'paper.pdf',dest/'supporting_materials.zip']:
    data=path.read_bytes();manifest[path.name]={'bytes':len(data),'md5':hashlib.md5(data).hexdigest(),'sha256':hashlib.sha256(data).hexdigest()}
(dest.parent/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest,indent=2))
