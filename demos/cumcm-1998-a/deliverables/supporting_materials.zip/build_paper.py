"""Build the historical-demo paper, honest AI disclosure and support archive."""
import argparse
import csv
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import textwrap
from fractions import Fraction
import zipfile
import re

p=argparse.ArgumentParser();p.add_argument('--case',type=Path);p.add_argument('--baseline',type=Path,default=Path(__file__).parent);p.add_argument('--output',type=Path,required=True)
a=p.parse_args();case=a.case.resolve() if a.case else None;baseline=a.baseline.resolve();dest=a.output.resolve()
support=dest.parent/'support-source'
if support.exists():raise FileExistsError('Refusing to replace an existing support source')
dest.mkdir(parents=True,exist_ok=True);support.mkdir()
r=json.loads((baseline/'reference/results.json').read_text(encoding='utf-8'));checks=json.loads((baseline/'reference/checks.json').read_text(encoding='utf-8'))
for sub in ['code','data','reference','figures']:shutil.copytree(baseline/sub,support/sub)
for name in ['check_return_target.py','check_target_certificates.py','equations.json']:
    shutil.copyfile(Path(__file__).with_name(name),support/name)
for name in ['return-targets.json','target-certificates.json','target-checks.json']:
    shutil.copyfile(Path(__file__).with_name(name),support/'reference'/name)
inverse=json.loads(Path(__file__).with_name('return-targets.json').read_text(encoding='utf-8'))['groups']
shutil.copyfile(Path(__file__).with_name('run_demo.py'),support/'run_demo.py')
shutil.copyfile(__file__,support/'build_paper.py')

shutil.copyfile(Path(__file__).with_name('check_recommendation.py'),support/'check_recommendation.py')
shutil.copyfile(Path(__file__).with_name('check_capital_threshold.py'),support/'check_capital_threshold.py')
shutil.copyfile(Path(__file__).with_name('check_robustness.py'),support/'check_robustness.py')
shutil.copyfile(Path(__file__).with_name('check_alternatives.py'),support/'check_alternatives.py')
shutil.copyfile(Path(__file__).with_name('alternatives.json'),support/'reference/alternatives.json')
shutil.copyfile(Path(__file__).with_name('robustness.json'),support/'reference/robustness.json')
shutil.copyfile(Path(__file__).with_name('recommendation.json'),support/'reference/recommendation.json')
rec=json.loads(Path(__file__).with_name('recommendation.json').read_text(encoding='utf-8'))['groups']

shutil.copyfile(Path(__file__).with_name('runtime-versions.json'),support/'runtime-versions.json')
versions=json.loads(Path(__file__).with_name('runtime-versions.json').read_text(encoding='utf-8'))
(support/'requirements.txt').write_text('\n'.join(f'{k}=={v}' for k,v in versions.items())+'\n', encoding='utf-8')

source_url='https://www.mcm.edu.cn/upload_cn/node/1/SkAh1A7Q6f2dd01e58aa621f920e79f45cd5d255.pdf'
format_url='https://www.mcm.edu.cn/html_cn/node/4cd596519c9eb9fbd866398f6df0caa3.html'
ai_url='https://www.mcm.edu.cn/html_cn/node/fef94648f2836ab6cc81586f4c38512b.html'
(support/'sources.json').write_text(json.dumps({'historical_problem':'CUMCM 1998 A','official_url':source_url,
 'pdf_page':11,'official_pdf_sha256':hashlib.sha256((case/'raw/problem/official-1992-2000.pdf').read_bytes()).hexdigest() if case else json.loads((baseline/'sources.json').read_text())['official_pdf_sha256'],
 'tables':'Two tables manually transcribed and visually reviewed by the AI assistant; not human verification.',
 'format_reference':format_url,'ai_policy_reference':ai_url,'review_date':'2026-10-12'},ensure_ascii=False,indent=2), encoding='utf-8')

(support/'README.md').write_text('# 《投资的收益和风险》支撑材料\n\n## 结果复现\n\n采用 Python 3.12，安装 requirements.txt 中列出的依赖，在本目录执行：\n\n    uv venv .venv --python 3.12\n    uv pip install --python .venv/bin/python -r requirements.txt\n    .venv/bin/python run_demo.py\n\nWindows 将 .venv/bin/python 替换为 .venv/Scripts/python.exe。\n\nrun_demo.py 读取 data/ 的两组资产参数，运行 code/model.py 求解和 code/validate.py 独立核验，再与 reference/results.json 比较。生成结果写入 reproduced/；若该目录已存在则拒绝覆盖。模型计算采用资金 100 万元，风险上限与论文一致；资金与风险定义及适用条件见论文。\n\n## 文件用途\n\n- code/model.py：建模、优化求解、风险—收益曲线和结果生成。\n- code/validate.py：约束、现金流、解析上界及四资产费用分区穷举核验。\n- run_demo.py：完整计算与验证入口；运行不依赖 Praxis 或 AI 服务。\n- data/：题目两组资产参数；出处与录入核对情况见 sources.json。\n- check_capital_threshold.py：资金规模的充分阈值（论文第 6.2 节的 338.86 元与 2601.34 元）；结果写入 reproduced/。\n- check_recommendation.py：定位收益—风险曲线的拐点，并以解析上界核验；结果写入 reproduced/recommendation.json。\n- check_robustness.py：对拐点方案做执行误差、安全余量与数据误差的随机试验（种子固定）；结果写入 reproduced/robustness.json。\n- check_alternatives.py：与简单规则、逐项剔除资产以及把风险率当作标准差的另一种读法比较；结果写入 reproduced/alternatives.json。\n- check_return_target.py：给定目标净收益率，最小化原手续费模型的风险；默认目标为说明方法的示例，命令 --group four --target 0.20 --budget 1000000 可改输入。\n- check_target_certificates.py：从 CSV 重算有理数对偶界、原手续费证书、不可达边界与 100 元的16支持反例，不导入优化求解器；--numeric 可核对新求解的 return-targets.json。\n- reference/：论文对应结果、曲线数值及核验记录；target-certificates.json 含确切证书，target-checks.json 含真实重算结论。\n- figures/：运行结果生成的风险—收益图；论文中的图由 LaTeX 直接绘制。\n- requirements.txt、runtime-versions.json：计算依赖和版本。\n- paper/main.tex、paper/ai-use.tex：论文与 AI 使用详情的 LaTeX 源文件，正式成品固定使用 Tectonic 0.17.0 与 default_bundle_v33（中文为 Fandol 0.3，不依赖系统字体）；XeLaTeX 仅用于另行检查，不能保证版式相同。build_paper.py 生成这两个源文件并使用固定编译环境，需原案例运行记录和原题副本；不是数学结果复现入口。\n- AI工具使用详情.pdf：AI 工具名称、用途、过程及采纳与核验情况。\n\n完整建模、核验和复现源程序同时列于论文附录 B。支撑材料文件清单列于论文附录 A。\n', encoding='utf-8')
import subprocess
out=[]
title,heading1,heading2,heading,small,style='title','h1','h2','h2','small',None
UNI={'λ':r'$\lambda$','□':r'$\square$','≥':r'$\geq$','≤':r'$\leq$','ρ':r'$\rho$','η':r'$\eta$','≈':r'$\approx$','≠':r'$\neq$','→':r'$\rightarrow$','∈':r'$\in$','∑':r'$\sum$','²':r'$^2$','³':r'$^3$','⁴':r'$^4$','γ':r'$\gamma$','μ':r'$\mu$','σ':r'$\sigma$','Δ':r'$\Delta$','∞':r'$\infty$','−':'-'}
def esc(s):
    s=s.replace('\\',r'\textbackslash{}')
    for a,b in [('&',r'\&'),('%',r'\%'),('$',r'\$'),('#',r'\#'),('_',r'\_'),('{',r'\{'),('}',r'\}'),('~',r'\textasciitilde{}'),('^',r'\textasciicircum{}')]:
        s=s.replace(a,b)
    return ''.join(UNI.get(c,c) for c in s)
SYM=re.compile(r'(\b(?:[xrfqpuhvtwgy][0i]|rho)\b\*?|ηi)')
URL=re.compile(r'(https?://[^\s，。；）)]+[^\s，。；）).,;])')
def T(text):
    maths=re.split(r'(\$[^$]+\$)',str(text))
    if len(maths)>1:return ''.join(piece if i%2 else T(piece) for i,piece in enumerate(maths))
    parts=URL.split(str(text))
    if len(parts)>1:return ''.join((r'\url{'+x+'}') if i%2 else T(x) for i,x in enumerate(parts))
    res=[]
    for piece in SYM.split(str(text)):
        star=piece.endswith('*') and len(piece)>1
        core=piece[:-1] if star else piece
        if core=='ηi':res.append(r'$\eta_i$')
        elif re.fullmatch(r'[xrfqpuhvtwgy][0i]',core):res.append('$%s_%s%s$'%(core[0],core[1],'^*' if star else ''))
        elif core=='rho':res.append(r'$\rho'+('^*' if star else '')+'$')
        else:res.append(esc(piece))
    return re.sub(r'@(tab|fig):(\d+)@',r'\\ref{\1:\2}',''.join(res))
def para(text,kind=None):
    if kind==title:out.append(r'\begin{center}{\bfseries\zihao{3} '+T(text)+r'}\end{center}'+'\n')
    elif kind==heading1:out.append(r'\section*{'+T(text).replace(' ',r'\hspace{1em}')+'}\n')
    elif kind==small:out.append(r'\begingroup\small\sloppy\raggedright\setlength{\parindent}{0pt}\hangindent=2em '+T(text)+r'\par\endgroup'+'\n')
    else:out.append(re.sub(r'\[(\d+)\]',r'\\textsuperscript{[\1]}',T(text))+'\n')
SECN=[0]
def section(text):
    m2=re.match(r'^(\d+)\.(\d+)\s+(.*)$',text);m1=re.match(r'^(\d+)\s+(.*)$',text)
    if m2:out.append(r'\subsection{'+T(m2.group(3))+'}\n')
    elif m1:
        SECN[0]+=1;assert int(m1.group(1))==SECN[0],text
        out.append(r'\section{'+T(m1.group(2))+'}\n')
    else:out.append(r'\section*{'+T(text)+'}\n')
def newpage():out.append(r'\clearpage'+'\n')
def need(pt):out.append(r'\Needspace{%dpt}'%pt+'\n')
equations=json.loads((Path(__file__).with_name('equations.json')).read_text(encoding='utf-8'))
def equation(index):out.append(r'\begin{equation}'+equations[index]['tex']+r'\end{equation}'+'\n')
table_count=0
def is_number(v):return re.fullmatch(r'[-+]?[\d,]*\.?\d+%?',str(v)) is not None
def table(rows,widths=None):
    global table_count
    table_count+=1
    introductions={
      2:'下文采用表 @tab:2@ 的符号和单位；购买本金、交易费用与银行余额分别记账，以便核对预算和净收益。',
      3:'四资产的代表方案见表 @tab:3@，相应购买额和费用列于表 @tab:4@；两表共同给出风险上限、实际暴露与现金流的对应关系。',
      5:'十五资产的代表结果见表 @tab:5@；比较风险上限与实际风险，可以区分仍受风险约束的方案和收益已进入平台的方案。',
      6:'风险上限为 10% 时的启用资产及交易费用见表 @tab:6@，可据此逐项核对该代表方案的购买支出。',
      7:'资金变化的结果分别列于表 @tab:7@ 和表 @tab:8@。净收益率随小资金规模变化，反映最低交易费的影响；进入比例计费区间后，归一化收益趋于稳定。',
      9:'表 @tab:9@ 将目标净收益率转换为最低所需风险。所有目标均为示例输入；原手续费可行证书与对偶下界精确一致。',
      10:'附录表 @tab:10@ 列全十五资产输入，使正文结果可以从原始收益率、风险率、费用和门槛逐项复核。',
    }
    if table_count in introductions:para(introductions[table_count])
    names=['四资产题设参数','符号与单位','四资产代表方案收益','四资产购买本金及交易费用（元）','十五资产代表方案收益','十五资产代表配置','四资产资金规模情景','十五资产资金规模情景','目标收益与最小风险','十五资产题设参数']
    n=len(rows[0]);long_last=any(len(str(r[-1]))>24 for r in rows[1:])
    cols=''.join('r' if all(is_number(r[j]) for r in rows[1:]) else 'l' for j in range(n))
    env='tabular';arg=''
    if long_last:cols=cols[:-1]+'X';env='tabularx';arg=r'{\linewidth}'
    body=r' \\'+'\n'
    lines=[' & '.join(T(c) for c in row) for row in rows]
    out.append(r'\begin{table}[htbp]\centering\small\caption{'+names[table_count-1]+'}'+r'\label{tab:'+str(table_count)+'}'+'\n\\begin{'+env+'}'+arg+'{'+cols+'}\n\\toprule\n'+lines[0]+r' \\ \midrule'+'\n'+body.join(lines[1:])+r' \\ \bottomrule'+'\n\\end{'+env+'}\n\\end{table}\n')
def fig_caption(n,text,note):
    out.append(r'\caption{'+T(text)+r'}'+r'\label{fig:'+str(n)+'}'+'\n'+r'\par\vspace{2pt}{\footnotesize 注：'+T(note)+r'}'+'\n'+r'\end{figure}'+'\n')
def pgf_figure(key,n,text,note):
    rows=list(csv.DictReader((support/f'reference/{key}-frontier.csv').open()))
    line=' '.join('(%.4f,%.4f)'%(float(d['risk_cap'])*100,float(d['net_return'])*100) for d in rows)
    sel=' '.join('(%.4f,%.4f)'%(100*d['actual_risk'],100*d['net_return']) for d in r['groups'][key]['selected'])
    kn=rec[key];kx,ky=kn['knee_risk']*100,kn['knee_net_return']*100
    out.append(r'''\begin{figure}[htbp]\centering
\begin{tikzpicture}
\begin{axis}[scale only axis,width=0.78\linewidth,height=6.2cm,xlabel={风险上限（占初始资金的百分比）},ylabel={净收益率（\%%）},axis lines=left,axis line style={gray!70},grid=major,grid style={gray!18},clip=false,tick label style={font=\footnotesize},label style={font=\small},legend style={font=\footnotesize,draw=none,fill=none,at={(0.5,1.04)},anchor=south,legend columns=-1,/tikz/every even column/.append style={column sep=8pt}},every axis plot/.append style={line cap=round}]
\addplot[color=main,line width=1.1pt] coordinates {%s};
\addplot[only marks,mark=*,mark size=2pt,color=accent] coordinates {%s};
\addplot[only marks,mark=star,mark size=4pt,color=accent,line width=0.8pt] coordinates {(%.4f,%.4f)} node[anchor=north west,font=\footnotesize,xshift=3pt,yshift=-3pt,text=black!70] {拐点 %.1f\%%，%.2f\%%};
\legend{最优净收益率,代表方案,几何拐点}
\end{axis}
\end{tikzpicture}
'''%(line,sel,kx,ky,kx,ky))
    fig_caption(n,text,note)

GOPT=r"axis lines=left,axis line style={gray!70},grid=major,grid style={gray!18},clip=false,tick label style={font=\footnotesize},label style={font=\small},title style={font=\small\bfseries},every axis plot/.append style={line cap=round}"
def fig_wrap(body,n,text,note):
    out.append('\\begin{figure}[htbp]\\centering\n\\begin{tikzpicture}\n'+body+'\n\\end{tikzpicture}\n')
    fig_caption(n,text,note)
def fig_margin_error(f4,f15,n):
    b4=' '.join('(%d,%.3f)'%(round(d['buffer']*100),(f4['nominal_net_return']-d['net_return'])*100) for d in f4['buffer_price'])
    b15=' '.join('(%d,%.3f)'%(round(d['buffer']*100),(f15['nominal_net_return']-d['net_return'])*100) for d in f15['buffer_price'])
    e=lambda g,k:g['execution_error'][k]['median_overshoot']*100
    body=r"""\begin{groupplot}[group style={group size=2 by 1,horizontal sep=2.2cm},width=0.38\linewidth,height=5.0cm,scale only axis,%s]
\nextgroupplot[title={(a) 预留余量的代价},xlabel={风险上限收紧幅度（\%%）},ylabel={净收益率下降（百分点）},xtick={0,5,10},xmin=-1,xmax=11,ymin=0,ymax=1.6]
\addplot[color=main,mark=*,mark size=2pt,line width=1.1pt] coordinates {%s};
\addplot[color=accent,mark=square*,mark size=2pt,line width=1.1pt] coordinates {%s};
\node[anchor=south west,font=\footnotesize,text=accent] at (axis cs:6,0.32) {十五资产};
\node[anchor=south west,font=\footnotesize,text=main] at (axis cs:6,1.05) {四资产};
\nextgroupplot[title={(b) 操作误差造成的越界},symbolic x coords={five,ten},xtick=data,xticklabels={{$\pm 5\%%$},{$\pm 10\%%$}},xlabel={每项投资额的随机误差幅度},ylabel={风险额超出上限（\%%）},ybar,bar width=10pt,enlarge x limits=0.35,ymin=0,ymax=12,ymajorgrids=true,xmajorgrids=false,error bars/y dir=plus,error bars/y explicit,error bars/error mark=-,error bars/error bar style={black!70,line width=0.6pt},error bars/error mark options={black!70,mark size=2pt}]
\addplot[fill=main,draw=none] table[row sep=\\,x=x,y=y,y error=e] {x y e \\ five %.3f %.3f \\ ten %.3f %.3f \\};
\addplot[fill=accent,draw=none] table[row sep=\\,x=x,y=y,y error=e] {x y e \\ five %.3f %.3f \\ ten %.3f %.3f \\};
\node[font=\footnotesize,anchor=north west] at (rel axis cs:0.03,0.97) {\textcolor{main}{$\blacksquare$}\ 四资产\quad\textcolor{accent}{$\blacksquare$}\ 十五资产};
\end{groupplot}"""%(GOPT,b4,b15,e(f4,'0.05'),(f4['execution_error']['0.05']['p95_overshoot']-f4['execution_error']['0.05']['median_overshoot'])*100,e(f4,'0.10'),(f4['execution_error']['0.10']['p95_overshoot']-f4['execution_error']['0.10']['median_overshoot'])*100,e(f15,'0.05'),(f15['execution_error']['0.05']['p95_overshoot']-f15['execution_error']['0.05']['median_overshoot'])*100,e(f15,'0.10'),(f15['execution_error']['0.10']['p95_overshoot']-f15['execution_error']['0.10']['median_overshoot'])*100)
    fig_wrap(body,n,'安全余量的代价与操作误差的危害','左图：相对未预留余量的方案，收紧风险上限后最优净收益率的下降；右图：拐点方案在每项投资额独立加随机误差后风险额超出上限的中位数（柱）与 95% 分位（须线上端），各 200 次，种子固定；左图三点之间的连线只是引导视线，未计算中间值。')
def fig_baselines(a4,a15,n):
    def ser(g,key):return ' '.join('(%s,%.3f)'%(lab,100*d[key]) for lab,d in zip(['{拐点的一半}','{拐点}','{拐点的两倍}'],g['baselines']))
    panels=[]
    for title,g,first in (('(a) 四资产',a4,True),('(b) 十五资产',a15,False)):
        panels.append(r"""\nextgroupplot[title={%s},symbolic x coords={{拐点的一半},{拐点},{拐点的两倍}},xtick=data,ymin=0,ybar,bar width=7pt,enlarge x limits=0.22,%s xlabel={风险上限},ymajorgrids=true,xmajorgrids=false]
\addplot[fill=main,draw=none] coordinates {%s};
\addplot[fill=accent,draw=none] coordinates {%s};
\addplot[fill=muted!70,draw=none] coordinates {%s};"""%(title,'ylabel={净收益率（\\%）},' if first else '',ser(g,'optimal'),ser(g,'greedy_return_over_risk'),ser(g,'equal_weight_eligible')))
    leg=r"\node[font=\footnotesize,anchor=south] at ($(group c1r1.north)!0.5!(group c2r1.north)+(0,0.9cm)$) {\tikz{\fill[main](0,0)rectangle(0.25,0.18);}\ 最优方案\quad\tikz{\fill[accent](0,0)rectangle(0.25,0.18);}\ 收益／风险排序\quad\tikz{\fill[muted!70](0,0)rectangle(0.25,0.18);}\ 平均分配};"
    body=r"""\begin{groupplot}[group style={group size=2 by 1,horizontal sep=1.6cm},width=0.38\linewidth,height=5.0cm,scale only axis,%s]
%s
\end{groupplot}
%s"""%(GOPT,'\n'.join(panels),leg)
    fig_wrap(body,n,'简单规则与最优方案的差距','三个风险上限为拐点的一半、拐点和两倍；按 ηi 排序的贪心规则（以及在这两组数据上次序相同的收益率减费率排序）在六个情形都与最优一致，所以并入第一类柱。')
def fig_dropone(a4,a15,n):
    panels=[]
    for title,g,first in (('(a) 四资产',a4,True),('(b) 十五资产',a15,False)):
        rows=g['drop_one'];k=len(rows)
        ticks=','.join(str(i) for i in range(k));labs=','.join('{S%d}'%d['asset'] for d in rows)
        vals=' '.join('(%.3f,%d)'%(100*(g['nominal']-d['net_return_without']),i) for i,d in enumerate(rows))
        panels.append(r"""\nextgroupplot[title={%s},xbar,bar width=9pt,xmin=0,xmax=%.0f,y dir=reverse,ytick={%s},yticklabels={%s},ytick style={draw=none},xlabel={净收益率下降（百分点）},enlarge y limits=0.15,xmajorgrids=true,ymajorgrids=false,ylabel={%s}]
\addplot[fill=main,draw=none] coordinates {%s};

"""%(title,6,ticks,labs,'被去掉的资产' if first else '',vals))
    body=r"""\begin{groupplot}[group style={group size=2 by 1,horizontal sep=2.0cm},width=0.34\linewidth,scale only axis,%s]
%s
\end{groupplot}"""%(GOPT,'\n'.join(panels))
    body=body.replace('width=0.34\\linewidth,','width=0.34\\linewidth,height=4.2cm,',1)
    fig_wrap(body,n,'逐项剔除资产的收益损失','在拐点风险上限下，每次去掉一个被选资产后重新求解；以原方案收益率为基准，两图使用相同尺度。损失表示给定资产集合和风险上限下的替代代价。')
PREAMBLE=r'''\documentclass[a4paper,12pt,fontset=none]{ctexart}
\setCJKmainfont[BoldFont=FandolSong-Bold.otf,ItalicFont=FandolSong-Regular.otf,BoldItalicFont=FandolSong-Bold.otf]{FandolSong-Regular.otf}
\setCJKsansfont[BoldFont=FandolHei-Bold.otf]{FandolHei-Regular.otf}
\setCJKmonofont[BoldFont=FandolSong-Bold.otf]{FandolSong-Regular.otf}

\usepackage[top=2.54cm,bottom=2.54cm,left=2.8cm,right=2.8cm]{geometry}
\usepackage{amsmath,amssymb,amsthm}
\usepackage{newtxtext,newtxmath}
\usepackage{booktabs,graphicx,xcolor,pgfplots,caption,needspace,fvextra,array,tabularx}
\usepackage[hidelinks,pdfauthor={},pdftitle={%s}]{hyperref}
\urlstyle{same}\Urlmuskip=0mu plus 1mu
\renewcommand{\CJKttdefault}{\CJKrmdefault}
\pgfplotsset{compat=1.17}
\usepgfplotslibrary{groupplots}
\definecolor{muted}{HTML}{7A7F85}
\definecolor{main}{HTML}{0072B2}\definecolor{accent}{HTML}{D55E00}
\linespread{%s}
\setlength{\parskip}{0pt}
\ctexset{section={format=\bfseries\zihao{4}\centering,name={,},number=\arabic{section},aftername=\quad,beforeskip=2.4ex plus .4ex,afterskip=1.6ex},
 subsection={format=\bfseries\zihao{-4}\raggedright,name={,},number=\arabic{section}.\arabic{subsection},aftername=\quad,beforeskip=1.8ex plus .3ex,afterskip=1ex}}
\DeclareCaptionLabelFormat{heiti}{{\bfseries #1\,#2}}
\captionsetup{labelformat=heiti,labelsep=quad,font=small,justification=centering}
\captionsetup[table]{position=above,skip=5pt}\captionsetup[figure]{position=below,skip=4pt}
\setlength{\abovedisplayskip}{8pt}\setlength{\belowdisplayskip}{8pt}
\pagestyle{plain}
\begin{document}
'''
def build(stem,doc_title,spacing='1.3',size_opt=None):
    pre=PREAMBLE%(doc_title,spacing)
    if stem == "main":
        pre='\\newcommand{\\PraxisTitle}{@@TITLE@@}\n% BEGIN PRAXIS CUMCM STYLE v2\n% Praxis CUMCM house style v2; content and contest rules are separate.\n\\documentclass[a4paper,12pt,fontset=none]{ctexart}\n\\usepackage[top=2.54cm,bottom=2.54cm,left=2.8cm,right=2.8cm]{geometry}\n\\setCJKmainfont[BoldFont=FandolSong-Bold.otf,ItalicFont=FandolSong-Regular.otf,BoldItalicFont=FandolSong-Bold.otf]{FandolSong-Regular.otf}\n\\setCJKsansfont[BoldFont=FandolHei-Bold.otf]{FandolHei-Regular.otf}\n\\setCJKmonofont[BoldFont=FandolSong-Bold.otf]{FandolSong-Regular.otf}\n\\usepackage{amsmath,amssymb,amsthm}\n\\usepackage{newtxtext,newtxmath}\n\\usepackage{booktabs,graphicx,xcolor,pgfplots,caption,needspace,fvextra,array,tabularx}\n\\usepackage[hidelinks,pdfauthor={},pdftitle={\\PraxisTitle}]{hyperref}\n\\urlstyle{same}\\Urlmuskip=0mu plus 1mu\n\\renewcommand{\\CJKttdefault}{\\CJKrmdefault}\n\\pgfplotsset{compat=1.17}\n\\usepgfplotslibrary{groupplots}\n\\definecolor{muted}{HTML}{7A7F85}\n\\definecolor{main}{HTML}{0072B2}\\definecolor{accent}{HTML}{D55E00}\n\\linespread{1.3}\n\\setlength{\\parskip}{0pt}\n\\ctexset{section={format=\\bfseries\\zihao{4}\\centering,name={,},number=\\arabic{section},aftername=\\quad,beforeskip=2.4ex plus .4ex,afterskip=1.6ex},\n subsection={format=\\bfseries\\zihao{-4}\\raggedright,name={,},number=\\arabic{section}.\\arabic{subsection},aftername=\\quad,beforeskip=1.8ex plus .3ex,afterskip=1ex}}\n\\DeclareCaptionLabelFormat{heiti}{{\\bfseries #1\\,#2}}\n\\captionsetup{labelformat=heiti,labelsep=quad,font=small,justification=centering}\n\\captionsetup[table]{position=above,skip=5pt}\\captionsetup[figure]{position=below,skip=4pt}\n\\setlength{\\abovedisplayskip}{8pt}\\setlength{\\belowdisplayskip}{8pt}\n\\pagestyle{plain}\n% END PRAXIS CUMCM STYLE\n\\begin{document}\n'.replace("@@TITLE@@",doc_title)
    if size_opt:pre=pre.replace('a4paper,12pt',size_opt)
    tex_dir=support/'paper';tex_dir.mkdir(exist_ok=True)
    (tex_dir/(stem+'.tex')).write_text(pre+'\n'.join(out)+'\n\\end{document}\n', encoding='utf-8')
    engine=shutil.which('tectonic') or str(Path.home()/'.local/bin/tectonic')
    version=subprocess.run([engine,'--version'],capture_output=True,text=True,check=True).stdout.strip()
    assert version=='Tectonic 0.17.0', 'Canonical output requires Tectonic 0.17.0'
    bundle='https://relay.fullyjustified.net/default_bundle_v33.tar'
    identity=subprocess.run([engine,'-X','bundle','cat','SHA256SUM'],cwd=tex_dir,capture_output=True,check=True).stdout.decode().strip()
    assert identity=='6ffe055852f8faf66c0acbe1a7fb27f87b869a90bad1204f3bf4d9683f597c7c', 'Unexpected TeX bundle'
    res=subprocess.run([engine,'--bundle',bundle,'--keep-logs',(stem+'.tex')],cwd=tex_dir,capture_output=True,text=True)
    (tex_dir/(stem+'.compile.log')).write_text(res.stdout+res.stderr, encoding='utf-8')
    assert res.returncode==0,res.stderr[-1500:]
    out.clear();return tex_dir/(stem+'.pdf')
def pct(v):return f'{v*100:.3f}%'
def money(v):return f'{0 if abs(v)<.005 else v:,.2f}'

para('投资的收益和风险：含最低交易费的组合优化',title)
para('摘 要',heading1)
f=r['groups']['four']['selected'][1];g=r['groups']['fifteen']['selected'][1]
para('针对含最低交易费的资产配置问题，建立银行存款与风险资产之间的收益—风险组合优化模型。将资金总额和可承受风险作为决策参数，在给定风险上限下最大化净收益，构造供公司选择的投资方案。')
para('将购买金额、交易费和银行存款共同纳入预算；不购买时费用为零，正购买时费用为费率乘购买金额与门槛金额的较大值。利用二元启用变量建立混合整数线性规划，并以最大单项风险损失额占初始资金比例作为风险指标。')
para(f'当可用资金为 100 万元时，四资产风险上限 1% 的净收益率为 {pct(f["net_return"])}；十五资产风险上限 10% 时为 {pct(g["net_return"])}。两组各计算 61 个风险上限，代表方案与解析上界吻合。进一步把目标净收益率作为输入，最小化所需风险：四资产要求 20% 时的最小风险为 0.587599%，十五资产要求 33% 时为 9.128131%。六个可达目标均由原费用可行方案与有理数对偶下界共同证明；27% 与 41% 分别超过两组全风险范围的最大净收益率，不可达。目标均为示例，不能代表公司的实际偏好。')
para('四资产进一步通过 81 种费用分段的枚举与连续背包计算独立核验。资金和风险参数情景揭示：最低交易费在小资金下会改变组合；将风险理解为所持资产中最大的风险率时，收益—风险曲线变成只买一项资产的阶梯，奖励集中而非分散。因此结果仅适用于所采用定义与题目参数，模型同时给出最低交易费生效条件。100 元、四资产、20% 目标的完整支持枚举反例证明：比例费用逆值只给必要下界，不能在小资金下自动当作最小风险。几何拐点保留作折中示例，实际配置由公司确认的目标与风险定义决定。')
para('关键词：投资组合；混合整数规划；最低交易费；风险约束；独立验证')
newpage()
section('1 问题重述与数据核对')
para('问题重述。公司有一笔数额为 M 的资金，可购买 n 种资产 Si，也可存银行（利率 r0=5%，无费用无风险）。购买 Si 的平均收益率为 ri、风险损失率为 qi，交易费率为 pi，购买额不超过 ui 时按 ui 计费；总体风险按所投资资产中最大的一个风险度量。原题要求：（1）对表 1 的四种资产设计投资组合，使净收益尽可能大、总体风险尽可能小；（2）讨论一般情形，并对表 10 的十五种资产计算。原始数据来自全国组委会官方历史赛题汇编第 11 页 [1]，收益率、风险损失率和费率在计算时由百分数转为小数，门槛金额以元计。本文的处理是：先固定风险上限求收益最优方案，再反解公司给定目标净收益时的最低所需风险；未获得偏好时保留方案族，拐点仅作几何折中示例。')
para('资金总额 M 与公司风险偏好未提供。本文取 M=1,000,000 元作为数值分析基准，并考察 M=100、1,000、10,000 元。资金总额保留为模型参数，各风险上限对应一个收益最优方案；公司可根据可承受风险选择配置。')
para('文献定位。含固定交易费与最小交易量的组合选择，在文献中通常写成混合整数线性规划，规模大时再用启发式求解 [4]；本题收益与损失率为给定参数、没有历史序列，不能估计 Markowitz 均值—方差模型所需的协方差 [5]。本文采用的最大单项损失额度量，与以最坏损失而非方差衡量风险、并可用线性规划处理的极小极大思路同属一类 [6]，但对象不同：它约束各资产风险损失额的最大值，而非历史收益序列的最小值。')
table([['资产','收益率 %','风险率 %','费率 %','门槛 元']]+[[d[k] for k in ['asset','return_pct','risk_pct','fee_pct','threshold_yuan']] for d in r['groups']['four']['assets']],[55,85,85,80,140])
para('要求与回答位置。四资产在给定风险上限下的最优方案见第 4 节；十五资产见第 5 节；含最低交易费的一般模型与精确求解见第 3 节；最优性证据与一般资金规模下的条件见第 6 节；资金、参数和风险定义的敏感性见第 7 节；目标收益对应的最低风险、缺少偏好时的折中示例及决策边界见第 8 节。')
section('2 假设、定义与符号')
para('采用单时期、无卖空、资金可连续分割；题目收益率与风险率视为本期给定参数。银行利率 r0=5%，无风险和交易费。没有观测时间序列，不估计相关性、收益分布或市场预测精度，也不将风险率解释成违约概率。税收、流动性与跨期再平衡不在题目数据内。')
table([['符号','含义与单位'],['M','初始可用资金，元'],['x0 / xi','银行存款 / 第 i 项购买本金，元'],['ri / qi / pi','收益率、题设风险损失率、交易费率，无量纲'],['ui / fi','费用计费门槛 / 实际交易费，元'],['yi','启用变量，0 或 1'],['rho / R','风险上限 / 最大单项风险暴露额占 M 的比例'],['T','公司要求的最低净收益率，本文只用示例输入'],['λ / A(λ)','非负预算对偶参数 / 风险界系数，无量纲']],[85,360])
para('风险采用最大单项金额暴露占初始资金的比例，而非所选资产风险率的最大值。这是本文为体现分散投资效果所采用的操作定义，不是由题目数据识别出的损失分布。原文的另一种解释在第 7 节比较。ui 是最低计费基数，不是最低购买额；交易费函数为：')
equation(0)
para('单时期、连续分割和忽略税收使预算模型可线性化；若交易要求整手购买，则需增加整数购买单位，本文结果不再直接适用。若费用另有资金支付或原题收益率已扣费，也须改变下面的现金流模型。')
section('3 一般模型与精确求解')
section('3.1 现金流与风险约束')
para('交易费在购买时从初始资金支付。期末财富由银行本息及风险资产本息组成；期末财富减去初始投入，得到净利润。因此费用只计入利润一次，不能因为预算也含费用就再重复扣减。')
equation(1);equation(2);equation(3);equation(4)
para('收益率为净利润除以初始资金。风险指标仅约束资金暴露；没有收益与损失的联合分布，故不把风险参数额外扣入期望收益。给定不同风险上限得到一族条件最优方案，全银行提供净收益率 5% 的可行基线。')
section('3.2 混合整数线性表示')
para('将金额除以初始资金归一化，避免资金尺度使约束系数悬殊。对每种资产加入二元启用变量；其具体定义和优化问题如下（所有逐项约束均对 i=1,…,n 成立）：')
equation(5);equation(6);equation(7);equation(8);equation(9)
para('当 yi=0 时购买额与费用均为零；当 yi=1 时费用至少等于两种计费值的较大者。由于过高费用既直接减少利润又占用可生息预算，最优解不会多付费用，故在最优解处该表示与分段收费等价。启用变量为 1 而购买额为零时，若费用为正，取消启用并把费用转存银行会严格增加收益；零费率时取消启用不影响收益。故总能选择与分段收费一致的最优解。费用上界利用归一化购买额不超过 1 推导，避免任意超大的常数。')
para('用 SciPy 的 milp 接口 [2] 和 HiGHS 求解 [3]，相对最优间隙设为 1e-9；每次求解均得到最优状态。每组扫描 61 个风险上限，四资产范围 0 到 3%，十五资产范围 0 到 60%。离散扫描展示收益包络，不声称给出全部连续前沿或所有并列最优解。')
section('4 四资产结果')
table([['风险上限','实际风险','净收益率','净收益 元','银行 元']]+[[pct(d['risk_cap']),pct(d['actual_risk']),pct(d['net_return']),money(d['profit_yuan']),money(d['bank_yuan'])] for d in r['groups']['four']['selected']],[75,75,80,115,100])
table([['风险上限','S1 本金','S2 本金','S3 本金','S4 本金','费用合计']]+[[pct(d['risk_cap'])]+[money(x) for x in d['investments_yuan']]+[money(sum(d['fees_yuan']))] for d in r['groups']['four']['selected']],[60,77,77,77,77,77])
para('图 @fig:1@ 将代表方案放回收益包络，显示提高风险上限的边际收益逐渐减小。风险上限 0.5% 时四种资产都有配置，并保留存款；到 1% 时方案集中在 S1 与 S2。该结果说明“分散越多越好”不是收益最优的通用规则；具体组合取决于风险限制和净收益机会成本。不同风险上限不能直接作优劣排名。')
pgf_figure('four',1,'四资产风险上限与最优净收益率','圆点为代表方案，星号为几何拐点（第 8 节），横轴为约束上限。')
section('5 十五资产结果与一般扩展')
table([['风险上限','实际风险','净收益率','净收益 元']]+[[pct(d['risk_cap']),pct(d['actual_risk']),pct(d['net_return']),money(d['profit_yuan'])] for d in r['groups']['fifteen']['selected']],[95,95,95,160])
para('十五资产采用与四资产完全相同的模型，全部参数见支撑材料 data/assets15.csv。一般 n 情形有 3n+1 个变量，其中 n 个二元变量；新增资产不要求更换方法。规模更大时求解耗时与启用组合有关，应保留实际最优间隙，不能只凭求解器返回可行解宣称全局最优。')
d=g;active=[(asset['asset'],x,fee) for asset,x,fee in zip(r['groups']['fifteen']['assets'],d['investments_yuan'],d['fees_yuan']) if x>1e-6]
table([['风险上限 10% 的启用资产','购买本金 元','交易费 元']]+[[name,money(x),money(fee)] for name,x,fee in active],[175,140,130])
para(f'图 @fig:2@ 显示十五资产收益包络的平台；继续放宽上限不一定增加收益。该方案交易费合计 {money(sum(g["fees_yuan"]))} 元。无风险限制时，四资产最优净收益率 {pct(r["groups"]["four"]["unrestricted"]["net_return"])}，十五资产为 {pct(r["groups"]["fifteen"]["unrestricted"]["net_return"])}；相应集中投资的风险更高。没有公司偏好输入，本文不把某个风险上限当作唯一最优；第 8 节按明确规则给出一个几何拐点。')
pgf_figure('fifteen',2,'十五资产最优收益包络','圆点为代表方案，星号为几何拐点（第 8 节）；平台区不表示风险上限全部被用尽。')
section('6 独立核验与最优性证据')
para('首先从原始 CSV 独立重算预算、分段费用、利润与实际风险，检查非负性和约束；随后检查零风险退化为全银行、收益包络单调以及无风险限制下的解析答案。')
para('四资产的核验不调用优化求解器：逐项取“不买／低于门槛／高于门槛”三种状态，共 81 种（四项资产各 3 种状态）。在每个状态中，费用已是仿射函数，资金约束成为带上下限的连续背包；先分配下限，再按边际利润与边际预算比从高到低分配，获得该状态的确切最优值。取所有状态的最大值，与 MILP 比较。')
section('6.1 比例费用松弛与解析上界')
para('命题 1（上界）。去掉最低计费门槛、仅保留比例费用 pi·xi 的松弛问题，其最优值 U 不小于原问题的最优值。')
out.append(r"\begin{proof}[证明]"+"\n")
para('设 x 为原问题的任一可行方案，其交易费 fi=pi·max(xi, ui) ≥ pi·xi。把 x 放入松弛问题，各项费用降为 pi·xi，节省的费用可存入银行；预算仍满足，风险暴露不变，净收益不减。因此 x 在松弛问题中可行且收益不低，U 是原问题的上界，不是另一个经验近似答案。')
out.append(r"\end{proof}"+"\n")
para('将银行余额由预算消去，松弛问题为：')
equation(10);equation(11);equation(12)
para('其中 wi 是每单位购买本金消耗的预算，gi 是扣除银行机会成本后的增量净收益。命题 2（松弛问题的解；设各 qi>0，ηi 并列时任取一种次序，结果相同）。只有 gi>0 的资产值得购买；按单位预算增益 ηi=gi/wi 从高到低依次分配，每种资产取剩余预算 B 与单项风险上限所允许的较小值：')
equation(13)
out.append(r"\begin{proof}[证明（交换论证）]"+"\n")
para('设某最优分配中，增益比较低的资产获得了正的预算，而增益比较高的资产尚未到达风险上限。把一小部分预算从前者转给后者，预算消耗不变，目标函数增加（两者增益比之差乘转移量），与最优性矛盾。故最优分配必按 ηi 排序，依次填满上限或耗尽预算，即得精确解 U。若净增益都非正，保留银行存款即可。')
out.append(r"\end{proof}"+"\n")
para('命题 3（最优性证书）。由命题 1，原问题任一可行方案的收益率不超过 U，因此可行方案的收益率等于 U 时它是全局最优：')
equation(14)
para('本次两组各三个代表方案以及第 8.2 节的两个几何拐点方案均达到上界。小资金方案可能落在最低费用段，不能自动使用上界相等的证书。')
section('6.2 一般资金规模下的解析条件')
para('命题 4（充分资金阈值）。记比例费用松弛的最优配置为归一化购买额 v*，给定风险上限，定义：')
equation(15)
out.append(r"\begin{proof}[证明]"+"\n")
para('当 M ≥ Mcrit 时，每个启用资产的购买本金 M·vi* 不低于门槛 ui，其费用 pi·max(xi, ui) 等于 pi·xi，故松弛最优配置对原问题可行且收益等于 U；由命题 1 它是原问题最优解，净收益率与 M 无关。')
out.append(r"\end{proof}"+"\n")
para('若没有资产启用，阈值记为零。若松弛最优配置唯一，且启用资产费率均为正，这个条件也是必要的：当 M<Mcrit 时，达到 U 的可行方案只能是 v* 本身，而 v* 中某个启用资产的购买额低于其门槛，实际费用高于 pi·xi，收益严格小于 U。本题两组启用资产的费率均为正，故这两个阈值是恰好的临界资金；松弛最优不唯一时，Mcrit 依赖于所取的最优配置，仍只是充分条件。低于阈值时应用分段费用模型求解。')
critical={}
for key in ['four','fifteen']:
    group=r['groups'][key];d=group['selected'][1]
    critical[key]=max(float(asset['threshold_yuan'])/(x/d['budget_yuan']) for asset,x in zip(group['assets'],d['investments_yuan']) if x>1e-7)
para(f'四资产风险上限 1% 时，资金阈值约为 {critical["four"]:.2f} 元；十五资产风险上限 10% 时约为 {critical["fifteen"]:.2f} 元。为避免金额四舍五入低于边界，可分别取 339 元与 2,602 元作为充分资金条件。该结论解释了第 7 节中资金超过门槛后最优收益率保持不变的现象。')
section('6.3 数值证据与检验边界')
passed=sum(c['passed'] for c in checks);para(f'核验共 {len(checks)} 项，全部通过，记录了实际误差、约束残差及证书间隙；这 12 项包含可行性、会计恒等式和性质检验，并非 12 种独立求解算法；真正独立的最优性核验为费用分段枚举与比例费用解析上界。资金为 100 万元时命题 4 说明整数模型与比例费用松弛等价，“达到解析上界”的证书在主结果上主要检验求解器；检验最低计费建模的是小资金情景，其费用分段枚举只覆盖四资产，十五资产的小资金情景依靠求解器的最优间隙证书。数值误差以 1e-7 的无量纲容差处理，金额表按分四舍五入，极小负银行残差在展示时记为零。')
need(170)
section('7 资金规模、参数与解释敏感性')
for key,label in [('four','四资产，风险上限 1%'),('fifteen','十五资产，风险上限 10%')]:
    para(label)
    table([['资金 元','净收益率','交易费 元']]+[[money(d['budget_yuan']),pct(d['net_return']),money(sum(d['fees_yuan']))] for d in r['sensitivity'][key]['budget']],[145,145,155])
para('资金情景是自行设定的压力检查，100 元情景偏离原题“相当大资金”的描述，专用于检验门槛。资金大到所有启用投资超过门槛后，比例归一化使最优收益率不再随 M 改变；资金小时固定最低计费会影响收益和选择。')
for key,label in [('four','四资产'),('fifteen','十五资产')]:
    ds=r['sensitivity'][key]['risk_stress'];para(label+'：将全部 qi 乘以 0.9、1、1.1，在同一风险上限下重新求解，收益率依次为 '+ '、'.join(pct(d['net_return']) for d in ds)+'。')
para('这三个乘数没有经验分布依据，只是参数情景，不是置信区间或真实发生概率。风险率增大使可行域缩小，最优收益不应增大，本次检查符合该性质。')
alt_rate=json.load(open(Path(__file__).with_name('alternatives.json')))['groups']
def rate_steps(key):return '；'.join(f'上限达到 {x["cap"]*100:.1f}% 时只买 '+'、'.join('S%d'%i for i in x['held_assets'])+f'（净收益率 {pct(x["net_return"])}）' for x in alt_rate[key]['rate_reading_frontier'] if x['held_assets'])
para('若将总体风险定义为已选资产中最大的风险率 qi，即每个被选资产自身的 qi 都不得超过上限，这个上限本身是一个风险率，要在它自己的尺度上扫描，不能沿用按金额占比定义的 1% 与 10%。结果是阶梯形的单资产方案：四资产，'+rate_steps('four')+'；十五资产，'+rate_steps('fifteen')+'。该读法只要求被选资产各自不超限，不惩罚把全部资金押在一项资产上，奖励集中而不是分散，与题面“投资越分散，总的风险越小”的说法相反，所以本文不采用，风险指标的操作定义应与公司的决策目标一致。')
section('8 从目标到投资决策')
section('8.1 目标净收益对应的最低风险')
para('公司若给出最低净收益率 T，直接在第 3 节原预算与最低收费约束下，加入净利润不低于 TM 的条件，并最小化最大单项损失比例 R。这把决策条件变成可检验的约束，不需要从曲线形状推断公司的偏好。银行提供 5% 净收益，因此 T 不超过 5% 时最小风险为零。')
out.append(r'\begin{equation}\min R\quad\text{s.t.}\quad P\ge TM,\quad x_0+\sum_i(x_i+f_i)=M,\quad q_ix_i\le RM.\end{equation}'+'\n')
para('命题 5（目标风险下界）。沿用第 6 节 wi、gi，令 zi=xi/M。任取非负 λ，并记 A(λ) 为下面的风险界系数，原费用方案均满足：')
out.append(r'\begin{equation} A(\lambda)=\sum_i\frac{(g_i-\lambda w_i)_+}{q_i},\qquad P/M\le r_0+\lambda+R A(\lambda).\end{equation}'+'\n')
out.append(r'\begin{equation} A(\lambda)>0\quad\Longrightarrow\quad R\ge\frac{T-r_0-\lambda}{A(\lambda)}.\end{equation}'+'\n')
out.append(r'\begin{proof}[证明]'+"\n")
para('实际费用不低于比例费用，所以原方案的 zi 满足购买预算加比例费不超过总资金，即 wi·zi 的总和不超过 1；净收益率不超过 r0 加 gi·zi 的总和。把 gi 拆成 λ·wi 与剩余项，负剩余项删去，正剩余项用 zi≤R/qi 代入，即得上界。目标收益不低于 T，移项得到风险必要下界。')
out.append(r'\end{proof}'+'\n')
para('按第 6 节单位预算增益的次序，比例费用上包络是连续、非减的分段直线。取边际资产的 ηi 作为 λ（全部正增益资产均到上限时取零），就能反解目标所在分支。四资产包络共 5 段、十五资产共 13 段；完整公式、端点与原模型证书由独立有理数核验器重算。若反解配置的所有正费率启用资产均超过计费门槛，该可行解达到风险下界，便是原收费模型的全局最小风险。资金条件按该目标的实际配置计算，不能沿用另一风险上限的门槛。')
out.append(r'\begin{equation}M_{\rm crit}(T)=\max_{i:z_i^*>0,\,p_i>0}\frac{u_i}{z_i^*},\qquad M\ge M_{\rm crit}(T).\end{equation}'+'\n')
exact_targets=json.loads(Path(__file__).with_name('target-checks.json').read_text())['groups']
def sufficient_funding(key,target):
    row=next(d for d in exact_targets[key]['target_cases'] if Fraction(d['target_net_return'])==Fraction(str(target)))
    cents=(100*Fraction(row['funding_threshold_yuan'])).__ceil__()
    yuan,cent=divmod(cents,100)
    return f'{yuan:,}.{cent:02d}'
table([['资产数','目标净收益率','最小风险','充分资金 元']]+[[label,pct(d['target_net_return']),f"{100*d['minimum_risk']:.6f}%",sufficient_funding(key,d['target_net_return'])] for key,label in [('four','4'),('fifteen','15')] for d in inverse[key][1:4]])
para('表中的充分资金由未舍入有理门槛向上取整到分，满足该金额即不会因门槛舍入而失去可行性。它不是将原最优购买额逐项取整到分；实际下单取整后仍须重验。')
para('例如四资产 20% 目标对应的风险为 12870/2190269，净利润恰为 20 万元；十五资产 33% 目标对应 7406225814/81136277107，净利润恰为 33 万元。两组最大净收益率分别为 27/101≈26.732673% 与 217/530≈40.943396%；预算全部用于含手续费的最高净收益资产可达到这两个上界，所以 27% 与 41% 目标确实不可达。证书采用连续金额的有理数；按分取整后须重验预算、收益与风险。')
para('小资金反例。四资产 M=100 元、T=20%，比例费逆值仍为 0.587599%。但该风险上限下购买额均低于计费门槛；完整枚举 16 个支持集，原费用最大净收益仅为 13.224127%，故这一风险及以下都达不到目标。另有只买 S1、风险 1.747989% 的原费用方案恰达到 20%，说明目标可达而松弛界不紧；这里没有把这个可行风险称为精确最小值。数值 MILP 可继续求小资金的原问题，界与最优性结论必须分开。')
section('8.2 缺少偏好时的几何折中')
para('优点是费用与预算一致、两组问题共用一般模型、有可复现输出与独立最优性证据。限制是最大单项损失只是一种题设风险代理，不是组合方差、尾部总损失或概率保证；缺少相关性与收益分布，不能代表真实市场投资。返回的是条件最优方案之一，而非所有可能的并列方案。')
fo,ff=rec['four'],rec['fifteen']
def plan(d,names):return '、'.join(f'{names[i]} {money(x)} 元' for i,x in enumerate(d['investments_yuan']) if x>1e-6)
para(f'折中示例。没有风险偏好输入时，保留收益—风险方案族；下面的拐点只是归一化几何折中示例：把净收益率从零风险值到饱和值、风险上限从零到饱和上限分别重标为 [0,1]，取曲线高出两端连线最多的一点。四资产拐点在风险上限 {fo["knee_risk"]*100:.1f}%：购买 {plan(fo,["S1","S2","S3","S4"])}，银行存款为零，净收益率 {pct(fo["knee_net_return"])}；已取得可得增益的 {fo["share_of_gain"]*100:.1f}%，风险上限只用了饱和上限（{fo["saturation_risk"]*100:.1f}%）的 {fo["share_of_saturation_risk"]*100:.0f}%。拐点前后局部斜率约为 {fo["slope_before"]:.1f} 与 {fo["slope_after"]:.1f}，即风险上限每提高 0.1 个百分点，净收益率约增加 {fo["slope_before"]/10:.2f} 与 {fo["slope_after"]/10:.2f} 个百分点。')
para(f'十五资产的拐点在 {ff["knee_risk"]*100:.0f}%（扫描步长 {ff["grid_step"]*100:.0f} 个百分点）：{plan(ff,["S%d"%i for i in range(1,16)])}；净收益率 {pct(ff["knee_net_return"])}，取得增益的 {ff["share_of_gain"]*100:.1f}%，风险上限仅为饱和上限（{ff["saturation_risk"]*100:.0f}%）的 {ff["share_of_saturation_risk"]*100:.0f}%。该曲线较平缓，拐点前后斜率只有 {ff["slope_before"]:.2f} 与 {ff["slope_after"]:.2f}，几何折中的依据弱于四资产。拐点取自上述网格，斜率也是网格上的割线；把网格细到 0.1 个百分点后，十五资产的拐点在 7.7%（净收益率 32.10%），四资产仍在 0.6%（20.19%），净收益率相差不到 0.2 个百分点，所以拐点只作近似位置使用。两个拐点处的可行方案都等于解析上界（{pct(fo["analytic_upper_bound"])}、{pct(ff["analytic_upper_bound"])}），因而是各自风险上限下的全局最优。拐点规则只是归一化后的几何折中约定，不代表公司的风险偏好，公司偏好明确时应直接按其风险上限选择。')
section('8.3 执行误差、比较基线与适用范围')
rb=json.load(open(Path(__file__).with_name('robustness.json')))['groups']
def rbp(k):return rb[k]
f4,f15=rbp('four'),rbp('fifteen')
para(f'拐点示例的执行误差与数据误差。拐点方案中有资产达到风险上限；在风险率不变时，增持这些资产可能越界，减持则不会因该项而越界。预算调整和其他资产的变化也会影响最终风险，不能把所有方向的误差都判为越界。对各项投资额独立加入 ±5% 的随机误差，各做 200 次：四资产只有 {f4["execution_error"]["0.05"]["share_within_cap"]:.0%} 的试验仍在上限内，风险额的中位数超出上限 {f4["execution_error"]["0.05"]["median_overshoot"]:.1%}；十五资产为 {f15["execution_error"]["0.05"]["share_within_cap"]:.0%}，超出 {f15["execution_error"]["0.05"]["median_overshoot"]:.1%}。误差放大到 ±10%，超出幅度约翻倍（{f4["execution_error"]["0.10"]["median_overshoot"]:.1%}、{f15["execution_error"]["0.10"]["median_overshoot"]:.1%}）。这不是净收益的问题，而是约束被穿透：带误差的购买额合计常超过资金（±5% 时四资产有 {f4["execution_error"]["0.05"]["share_scaled_to_budget"]:.0%} 的试验、十五资产有 {f15["execution_error"]["0.05"]["share_scaled_to_budget"]:.0%}），这里按预算等比例缩减后再计算，净收益率的中位数仍是 {pct(f4["execution_error"]["0.05"]["median_net_return"])} 与 {pct(f15["execution_error"]["0.05"]["median_net_return"])}（±5%），仅比无误差低 {(f4["nominal_net_return"]-f4["execution_error"]["0.05"]["median_net_return"])*100:.2f} 与 {(f15["nominal_net_return"]-f15["execution_error"]["0.05"]["median_net_return"])*100:.2f} 个百分点。以上比例来自 200 次试验，按二项分布估计，95% 区间的半宽在比例为一半时约为 7 个百分点，不宜解读到个位数。')
para(f'预留安全余量的代价（图 3）。把风险上限收紧 5% 再求最优，四资产净收益率从 {pct(f4["buffer_price"][0]["net_return"])} 降到 {pct(f4["buffer_price"][1]["net_return"])}，十五资产从 {pct(f15["buffer_price"][0]["net_return"])} 降到 {pct(f15["buffer_price"][1]["net_return"])}；收紧 10% 则降到 {pct(f4["buffer_price"][2]["net_return"])} 与 {pct(f15["buffer_price"][2]["net_return"])}。在风险率与总资金不变、执行误差仅改变购买额的条件下，设预留比例为 $s$、逐项正向误差不超过 $e$。执行后的最大单项风险不超过原上限的 $(1-s)(1+e)$ 倍；只要该乘积不超过 1，就能保证风险约束，必要的预算缩减不会增加风险。该保证不覆盖风险率本身的误差。')
fig_margin_error(f4,f15,3)
para(f'参数误差。对收益率、风险率、费率各项独立加入 ±10% 的随机误差（门槛不变），各做 200 次重新求解：最优资产组合几乎不变（四资产 {f4["parameter_error_10pct"]["share_same_assets"]:.0%}，十五资产 {f15["parameter_error_10pct"]["share_same_assets"]:.1%} 的试验中选择的资产相同），重新优化的净收益率在 {pct(f4["parameter_error_10pct"]["reoptimized_net_return"]["p05"])}–{pct(f4["parameter_error_10pct"]["reoptimized_net_return"]["p95"])}（四资产）与 {pct(f15["parameter_error_10pct"]["reoptimized_net_return"]["p05"])}–{pct(f15["parameter_error_10pct"]["reoptimized_net_return"]["p95"])}（十五资产，均为 5%–95% 分位）之间。原购买额在费率扰动后可能超出预算。保持原比例的收益对照先按新风险上限、再按含最低费用的预算缩减；未调整购买额只作诊断。若沿用原方案不调整，风险额中位数超出上限 {f4["parameter_error_10pct"]["kept_plan_risk_overshoot"]["median"]:.1%}、{f15["parameter_error_10pct"]["kept_plan_risk_overshoot"]["median"]:.1%}。结论：该拐点示例的组成比较稳健，风险上限的遵守不稳健；这些误差范围同样是设定的情景，没有经验分布依据。')
al=json.load(open(Path(__file__).with_name('alternatives.json')))['groups'];a4,a15=al['four'],al['fifteen']
def bl(g,i):return g['baselines'][i]
assert all(abs(b['greedy_eta']-b['optimal'])<1e-9 and abs(b['greedy_net_return']-b['optimal'])<1e-9 for g in (a4,a15) for b in g['baselines'])
para(f'与简单规则比较（图 4）。在 100 万元下，按命题 2 的单位预算增益 ηi 从高到低、每项买到风险上限允许的最大额的贪心规则，在三个风险上限（拐点的一半、拐点、两倍）下，两组共六个情形都与混合整数规划的最优值一致（差距小于 1e-12），这是命题 2 与命题 4 的直接结果：资金足够大时最低计费门槛不起作用，问题等价于带比例费用的线性规划。按“收益率减费率”排序在这两组数据上给出相同的次序，所以结果也相同，但它不是 ηi，一般数据下不保证最优。按“净收益率除以风险率”排序的规则在两倍拐点上限下低 {(bl(a4,2)["optimal"]-bl(a4,2)["greedy_return_over_risk"])*100:.1f}（四资产）与 {(bl(a15,2)["optimal"]-bl(a15,2)["greedy_return_over_risk"])*100:.1f}（十五资产）个百分点；在可买资产中平均分配的规则在拐点上限下只有 {pct(bl(a4,1)["equal_weight_eligible"])} 与 {pct(bl(a15,1)["equal_weight_eligible"])}，仅存银行为 5%。所以最低计费的整数模型在大资金下没有额外价值，在小资金（第 7 节）下才需要；决定结果的是“用满每项允许额”的排序。')
fig_baselines(a4,a15,4)
para(f'逐项剔除（图 5）。在拐点上限下去掉任一被选资产重新求解，四资产净收益率降到 {pct(min(d["net_return_without"] for d in a4["drop_one"]))}–{pct(max(d["net_return_without"] for d in a4["drop_one"]))}（原为 {pct(a4["nominal"])}），十五资产降到 {pct(min(d["net_return_without"] for d in a15["drop_one"]))}–{pct(max(d["net_return_without"] for d in a15["drop_one"]))}（原为 {pct(a15["nominal"])}）。在给定资产集合与风险上限下，各被选资产均提高最优收益，最容易替代的是十五资产中的 S{max(a15["drop_one"],key=lambda d:d["net_return_without"])["asset"]}（去掉后少 {(a15["nominal"]-max(d["net_return_without"] for d in a15["drop_one"]))*100:.2f} 个百分点）。')
fig_dropone(a4,a15,5)
ir4,ir15=a4['independent_risk_reading'],a15['independent_risk_reading']
para(f'另一种读法：在费用门槛与预算条件经核对后，利用柯西—施瓦茨不等式求精确配置。把风险率当作标准差，且各资产收益相互独立（这是本文为该读法补充的假设，题目没有给出），总风险取各项标准差的平方和开方。同样把上限设为拐点的 {ir4["cap"]*100:.1f}% 与 {ir15["cap"]*100:.0f}%，最优净收益率只有 {pct(ir4["net_return"])} 与 {pct(ir15["net_return"])}，十五资产的方案分散到 {ir15["std_plan_assets"]} 项资产。反过来，题设“最大单项损失”下的拐点方案，按这种读法的风险是 {ir4["knee_plan_std_risk"]*100:.2f}% 与 {ir15["knee_plan_std_risk"]*100:.1f}%，远高于 {ir4["cap"]*100:.1f}% 与 {ir15["cap"]*100:.0f}%。两种风险定义给出的方案不同，须先与公司确认；本段只作对照。')
para('建议公司先确认可用资金、目标净收益率和风险定义，再由目标反解最低风险或按明确风险上限选择方案；若有预计的操作误差，可按上述误差界计算必要余量（5%–10% 仅为本文示例）；若真实目标改成总损失、流动性或多时期决策，需要重新建模。提高模型复杂度不能弥补缺失数据。')
section('AI工具使用声明')
para('本论文由 AI 助手（OpenAI Codex；后期修订使用 Anthropic Claude Sonnet 5.5，通过 Claude Code）完成选题、模型推导、编程、计算、结果解释与论文撰写，2026 年 10 月 12 日由 OpenAI Codex 增加目标收益逆问题、独立有理证书及小资金反例；没有记录人工逐项审核；各项工具、过程与核验情况见支撑材料《AI工具使用详情》。')
need(230)
section('参考文献')
refs=[
 '[1] 全国大学生数学建模竞赛组委会. 1992—2000 年全国大学生数学建模竞赛赛题汇编：1998 年 A 题，PDF 第 11 页[EB/OL]. [2026-10-07]. '+source_url,
 '[2] SCIPY DEVELOPERS. scipy.optimize.milp: SciPy API reference[EB/OL]. [2026-10-07]. https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.milp.html',
 '[3] HiGHS DEVELOPMENT TEAM. HiGHS: high performance software for linear optimization[EB/OL]. [2026-10-07]. https://highs.dev/',
 '[4] KELLERER H, MANSINI R, SPERANZA M G. Selecting portfolios with fixed costs and minimum transaction lots[J]. Annals of Operations Research, 2000, 99: 287-304.',
 '[5] MARKOWITZ H. Portfolio selection[J]. The Journal of Finance, 1952, 7(1): 77-91.',
 '[6] YOUNG M R. A minimax portfolio selection rule with linear programming solution[J]. Management Science, 1998, 44(5): 673-683.']
for text in refs:para(text,small)
newpage()
section('附录 A 数据与支撑材料文件列表')
para('十五资产参数来自原题第二张表 [1]，供不运行程序的读者复核；收益、风险与费用列单位均为百分数，门槛为元。')
table([['资产','收益率 %','风险率 %','费率 %','门槛 元']]+[[d[k] for k in ['asset','return_pct','risk_pct','fee_pct','threshold_yuan']] for d in r['groups']['fifteen']['assets']],[55,85,85,80,140])
para('supporting_materials.zip 含以下文件；reproduced/ 为重跑时新生成，不纳入原提交包。各文件对应本文的数据、数值结果与计算过程。')
paths=sorted({path.relative_to(support).as_posix() for path in support.rglob('*') if path.is_file() and path.suffix not in ('.log',) and 'compile' not in path.name and not (path.parent.name=='paper' and path.suffix in ('.pdf',))}|{'paper/main.tex','paper/ai-use.tex','AI工具使用详情.pdf'})
rows=[paths[i:i+2]+['']*(2-len(paths[i:i+2])) for i in range(0,len(paths),2)]
out.append(r'\begin{center}\footnotesize\ttfamily\setlength{\tabcolsep}{4pt}\begin{tabular}{@{}p{0.47\linewidth}p{0.47\linewidth}@{}}'+'\n'+' \\\\\n'.join(' & '.join(esc(v) for v in row) for row in rows)+'\n\\end{tabular}\\end{center}\n')
newpage()
section('附录 B 完整源程序')
para('以下列出建模、独立核验和各节数字所依赖的全部源程序（共九个文件）；运行方法见附录 A 所列的运行说明。论文排版用的脚本不产生任何结果，不在此列。')
out.append(r'\begingroup\renewcommand{\theFancyVerbLine}{\rmfamily\scriptsize\arabic{FancyVerbLine}}'+'\n')
for index,path in enumerate([support/'code/model.py',support/'code/validate.py',support/'run_demo.py',support/'check_capital_threshold.py',support/'check_recommendation.py',support/'check_robustness.py',support/'check_alternatives.py',support/'check_return_target.py',support/'check_target_certificates.py']):
    out.append(r'\subsection*{'+esc(path.relative_to(support).as_posix())+'}\n'+r'\begin{Verbatim}[fontsize=\scriptsize,breaklines,breakanywhere,numbers=left,numbersep=5pt,numberblanklines=false,xleftmargin=1.6em,breaksymbolleft={},breakanywheresymbolpre={}]'+'\n'+path.read_text(encoding='utf-8')+'\n'+r'\end{Verbatim}'+'\n')
out.append(r'\endgroup'+'\n')
paper_pdf=build('main','投资的收益和风险：含最低交易费的组合优化')
shutil.copyfile(paper_pdf,dest/'paper.pdf')
# A separate disclosure has its own compact layout.
SECN[0]=0
para('AI工具使用详情',title)
para('历史题目演练；本说明如实记录当前可见过程，不是完整聊天导出。',small)
section('1 工具名称与型号')
para('使用的 AI 工具有两个：OpenAI Codex（初稿与计算流程；其系统标识为基于 GPT 的助手，具体模型版本无法独立核实，未作假定）和 Anthropic Claude Sonnet 5.5（通过 Claude Code，用于文献定位、几何拐点、独立审计后的修订以及重建论文与支撑包）。实际数学计算使用 Python 3.12、NumPy、SciPy/HiGHS 和 Matplotlib；初稿用 XeLaTeX（TeX Live 2026）排版；当前成品使用 Tectonic 0.17.0 与固定 v33 资源包。公式、表格和图由 LaTeX 排版与绘制。计算库版本保存在 requirements.txt。')
section('2 目的、提示方式与使用过程')
para('任务是挑选一道经典历史题，从题目分析、建模、验证到可提交文件完整演练一遍。本说明记录实际执行过程，不收录对话原文，也没有捏造其他提示或完整回复。')
para('助手自主选择 1998 A，读取官方原页并录入两张数据表；识别 M、风险偏好及风险定义缺口；提出含最低计费的 MILP；编写模型和不同数学构造的验证器；真实执行、比较资金与风险情景、形成图表与报告。本轮另查阅组委会公开论文展示 C023 的摘要与问题重述页，用于检查写作组织，未移植其模型、数据或结论；未获得可核实的 1998 A 官方标准答案。论文新增的三篇参考文献只核对了题录，未阅读全文，仅用于说明模型定位。')
section('3 采纳、修改与核验')
para('本稿采纳了助手提出的风险损失额定义、费用预算模型、MILP 表示、数值方案和报告表述。助手核验包括原页目视核对、预算和费用重算、四资产费用分段枚举、代表点解析上界、边界与参数单调性，并保留实际 checks.json。助手增加 100 元资金情景以检验最低费用边界。随后的审查覆盖字体、引文、方法与论文质量；助手修正宋体字面、公式、表格编号、参考文献和最优性推导，并把先前误称的 13 项检查纠正为真实的 12 项。此外，报告改为按考题直接作答：助手删除正文过程性旁注、重写摘要，并补充一般资金规模的充分阈值推导；实际人工核验状态仍在本说明如实记录。')
para('2026年10月9日，Codex修正了参数扰动下的收益比较：按新风险上限和含最低费用的预算等比例缩减；原超支只作诊断。独立风险对照改为闭式解并核对适用条件。补充情景重算，正文、代码和成品同步；主优化与原始数据不变。核验由AI完成，未新增人工审核。')
para('以上是 AI 助手核验和程序检查，不能称作用户或队伍人工审核。本次没有记录用户对核心假设、代码、结论和版面的逐项人工审核，也没有假称用户已作修改。正式比赛的真实队伍需主导核心分析并人工复核；本包仅为训练示范，不作正式合规认证。')
para('2026 年 10 月 12 日，OpenAI Codex 核读原题与当前 23 页稿，保留既有数据、122 个风险扫描结果及原误差情景；未重跑这些旧计算。新增目标净收益约束和风险最小化，实际求解六个非平凡百万元目标；以另一 AI 角色从原 CSV 独立构造 Fraction 解析包络、对偶界及原收费证书，并枚举 100 元情景的全部 16 个支持。任务目标是把几何折中改为明确决策条件；共享工作区中的数学复核不称严格隔离盲测，也未增加人工审核。研究参考学习不等于现实参数标定，示例收益目标不代表公司偏好。新增程序、证书和论文成品同步，具体 Codex 模型版本未独立核实。')
section('4 记录范围与出处')
para('本说明只含任务概述和当前实际执行摘要，不声称完整保存对话。没有导出系统提示、私密资料或隐含推理。格式依据为 2026 年试行规定，自 2026-09-01 起生效。出处：'+ai_url)

ai_pdf=build('ai-use','AI工具使用详情',spacing='1.25',size_opt='a4paper,11pt')
shutil.copyfile(ai_pdf,support/'AI工具使用详情.pdf')
for junk in (support/'paper').glob('*'):
    if junk.suffix in ('.pdf','.aux','.out') or junk.name.endswith('.log'):junk.unlink()
with zipfile.ZipFile(dest/'supporting_materials.zip','w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(support.rglob('*')):
        if path.is_file():z.write(path,path.relative_to(support))
manifest={}
for path in [dest/'paper.pdf',dest/'supporting_materials.zip']:
    data=path.read_bytes();manifest[path.name]={'bytes':len(data),'md5':hashlib.md5(data).hexdigest(),'sha256':hashlib.sha256(data).hexdigest()}
(dest.parent/'manifest.json').write_text(json.dumps(manifest,indent=2), encoding='utf-8')
print(json.dumps(manifest,indent=2))
