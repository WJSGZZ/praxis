# 《投资的收益和风险》支撑材料

## 结果复现

采用 Python 3.12，安装 requirements.txt 中列出的依赖，在本目录执行：

    uv venv .venv --python 3.12
    uv pip install --python .venv/bin/python -r requirements.txt
    .venv/bin/python run_demo.py

Windows 将 .venv/bin/python 替换为 .venv/Scripts/python.exe。

run_demo.py 读取 data/ 的两组资产参数，运行 code/model.py 求解和 code/validate.py 独立核验，再与 reference/results.json 比较。生成结果写入 reproduced/；若该目录已存在则拒绝覆盖。模型计算采用资金 100 万元，风险上限与论文一致；资金与风险定义及适用条件见论文。

## 文件用途

- code/model.py：建模、优化求解、风险—收益曲线和结果生成。
- code/validate.py：约束、现金流、解析上界及四资产费用分区穷举核验。
- run_demo.py：完整计算与验证入口；运行不依赖 Praxis 或 AI 服务。
- data/：题目两组资产参数；出处与录入核对情况见 sources.json。
- check_capital_threshold.py：资金规模的充分阈值（论文第 6.2 节的 338.86 元与 2601.34 元）；结果写入 reproduced/。
- check_recommendation.py：定位收益—风险曲线的拐点，并以解析上界核验；结果写入 reproduced/recommendation.json。
- check_robustness.py：对拐点方案做执行误差、安全余量与数据误差的随机试验（种子固定）；结果写入 reproduced/robustness.json。
- check_alternatives.py：与简单规则、逐项剔除资产以及把风险率当作标准差的另一种读法比较；结果写入 reproduced/alternatives.json。
- check_return_target.py：给定目标净收益率，最小化原手续费模型的风险；默认目标为说明方法的示例，命令 --group four --target 0.20 --budget 1000000 可改输入。
- check_target_certificates.py：从 CSV 重算有理数对偶界、原手续费证书、不可达边界与 100 元的16支持反例，不导入优化求解器；--numeric 可核对新求解的 return-targets.json。
- reference/：论文对应结果、曲线数值及核验记录；target-certificates.json 含确切证书，target-checks.json 含真实重算结论。
- figures/：运行结果生成的风险—收益图；论文中的图由 LaTeX 直接绘制。
- requirements.txt、runtime-versions.json：计算依赖和版本。
- paper/main.tex、paper/ai-use.tex：论文与 AI 使用详情的 LaTeX 源文件，正式成品固定使用 Tectonic 0.17.0 与 default_bundle_v33（中文为 Fandol 0.3，不依赖系统字体）；XeLaTeX 仅用于另行检查，不能保证版式相同。build_paper.py 生成这两个源文件并使用固定编译环境，需原案例运行记录和原题副本；不是数学结果复现入口。
- AI工具使用详情.pdf：AI 工具名称、用途、过程及采纳与核验情况。

完整建模、核验和复现源程序同时列于论文附录 B。支撑材料文件清单列于论文附录 A。
